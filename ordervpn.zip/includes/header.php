<?php
/**
 * OrderVPN - Header Template v2.0
 * Professional VPN Service Header with Dynamic Settings
 */
require_once __DIR__ . '/config.php';


$current_page = basename($_SERVER['PHP_SELF']);
$user = null;
$is_logged_in = isset($_SESSION['user_id']);

if ($is_logged_in) {
    $user = getCurrentUser();
}

$csrf_token = generateCsrfToken();
$app_name = getSetting('app_name', APP_NAME);
$app_tagline = getSetting('login_page_subtitle', 'Premium VPN Service');

// Maintenance mode check
if (getSetting('maintenance_mode') == '1' && !$is_logged_in) {
    ?>
    <!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Maintenance - <?= $app_name ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet"></head>
    <body class="bg-dark text-white d-flex align-items-center justify-content-center" style="min-height:100vh;">
    <div class="text-center"><div class="display-1 mb-4">🔧</div><h1 class="mb-3">Sedang Dalam Perbaikan</h1>
    <p class="text-muted">Website sedang maintenance. Silakan kembali lagi nanti.</p></div></body></html>
    <?php exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_logged_in ? 'Dashboard - ' : '' ?><?= $app_name ?> - <?= $app_tagline ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>:root{--primary-color:<?= getSetting('theme_primary_color','#4e73df') ?>;--secondary-color:<?= getSetting('theme_secondary_color','#858796') ?>;}</style>
</head>
<body id="page-top">

<?php if (getSetting('promo_banner_enabled')=='1' && !empty(getSetting('promo_banner_text'))): ?>
<div class="promo-banner">
    <div class="container d-flex align-items-center justify-content-between">
        <span class="promo-banner-text"><i class="fas fa-bullhorn me-2"></i><?= htmlspecialchars(getSetting('promo_banner_text')) ?></span>
        <button class="btn-close btn-close-white promo-banner-close" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?>

<?php if ($is_logged_in): ?>
<div class="floating-contact">
    <?php if (!empty(getSetting('whatsapp'))): ?>
    <a href="https://wa.me/<?= getSetting('whatsapp') ?>" target="_blank" class="floating-btn whatsapp" title="Hubungi WA"><i class="fab fa-whatsapp"></i></a>
    <?php endif; ?>
    <?php if (!empty(getSetting('telegram_channel'))): ?>
    <a href="<?= getSetting('telegram_channel') ?>" target="_blank" class="floating-btn telegram" title="Telegram"><i class="fab fa-telegram-plane"></i></a>
    <?php endif; ?>
</div>
<?php endif; ?>

<div id="loadingOverlay" class="loading-overlay" style="display:none;">
    <div class="spinner-wrapper">
        <div class="spinner-border text-primary" role="status" style="width:3rem;height:3rem;"></div>
        <p class="mt-2 text-muted">Memproses...</p>
    </div>
</div>

<div id="toastContainer" class="toast-container position-fixed top-0 end-0 p-3" style="z-index:9999;"></div>

<?php if (getSetting('promo_popup_enabled')=='1' && $is_logged_in): ?>
<div class="modal fade" id="promoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content promo-modal-content">
            <div class="modal-header border-0"><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body text-center py-4">
                <?php if (!empty(getSetting('promo_popup_image'))): ?>
                <img src="<?= getSetting('promo_popup_image') ?>" alt="Promo" class="img-fluid rounded mb-3" style="max-height:200px;">
                <?php endif; ?>
                <div class="promo-popup-icon mb-3"><i class="fas fa-gift fa-3x" style="color:var(--primary-color);"></i></div>
                <h4 class="fw-bold mb-2"><?= htmlspecialchars(getSetting('promo_popup_title','🎉 Promo Spesial!')) ?></h4>
                <p class="text-muted mb-4"><?= htmlspecialchars(getSetting('promo_popup_message','')) ?></p>
                <button class="btn btn-primary btn-lg px-5 promo-cta-btn" data-bs-dismiss="modal"><i class="fas fa-check me-2"></i>Dapatkan Promo</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($is_logged_in): ?>
<div id="wrapper">
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon"><i class="fas fa-shield-halbed"></i></div>
        <div class="sidebar-brand-text mx-3"><?= $app_name ?></div>
    </a>
    <hr class="sidebar-divider my-0">
    <li class="nav-item <?= $current_page=='dashboard.php'?'active':'' ?>">
        <a class="nav-link" href="dashboard.php"><i class="fas fa-fw fa-tachometer-alt"></i><span>Dashboard</span></a>
    </li>
    <hr class="sidebar-divider">
    <div class="sidebar-heading">Layanan</div>
    <li class="nav-item">
        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-fw fa-shopping-cart"></i><span>Order VPN</span></a>
    </li>
    <li class="nav-item <?= $current_page=='servers.php'?'active':'' ?>">
        <a class="nav-link" href="servers.php"><i class="fas fa-fw fa-server"></i><span>Status Server</span></a>
    </li>
    <li class="nav-item <?= $current_page=='topup.php'?'active':'' ?>">
        <a class="nav-link" href="topup.php"><i class="fas fa-fw fa-credit-card"></i><span>Top Up Saldo</span></a>
    </li>
    <hr class="sidebar-divider">
    <div class="sidebar-heading">Komunitas</div>
    <?php if (!empty(getSetting('telegram_group'))): ?>
    <li class="nav-item"><a class="nav-link" href="<?= getSetting('telegram_group') ?>" target="_blank"><i class="fab fa-fw fa-telegram"></i><span>Group Telegram</span></a></li>
    <?php endif; ?>
    <?php if (!empty(getSetting('instagram'))): ?>
    <li class="nav-item"><a class="nav-link" href="<?= getSetting('instagram') ?>" target="_blank"><i class="fab fa-fw fa-instagram"></i><span>Instagram</span></a></li>
    <?php endif; ?>
    <?php if (!empty(getSetting('whatsapp'))): ?>
    <li class="nav-item"><a class="nav-link" href="https://wa.me/<?= getSetting('whatsapp') ?>" target="_blank"><i class="fab fa-fw fa-whatsapp"></i><span>WhatsApp</span></a></li>
    <?php endif; ?>
    <?php if ($user && $user['role']==='admin'): ?>
    <hr class="sidebar-divider">
    <div class="sidebar-heading">Admin</div>
    <li class="nav-item <?= $current_page=='admin.php'?'active':'' ?>">
        <a class="nav-link" href="admin.php"><i class="fas fa-fw fa-cogs"></i><span>Admin Panel</span></a>
    </li>
    <?php endif; ?>
    <hr class="sidebar-divider d-none d-md-block">
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>

<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow-sm">
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3"><i class="fa fa-bars"></i></button>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link" href="#"><i class="fas fa-bell fa-fw"></i><span class="badge bg-danger badge-counter">3+</span></a>
        </li>
        <?php if ($user): ?>
        <li class="nav-item mx-2">
            <a class="nav-link" href="topup.php">
                <i class="fas fa-wallet fa-fw"></i>
                <span class="fw-bold ms-1" style="color:var(--primary-color);"><?= formatRupiah($user['saldo']??0) ?></span>
            </a>
        </li>
        <?php endif; ?>
        <div class="topbar-divider d-none d-sm-block"></div>
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= sanitize($user['username']??'') ?></span>
                <i class="fas fa-user-circle fa-2x text-gray-300"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in">
                <div class="dropdown-item-text d-flex align-items-center">
                    <div class="flex-shrink-0 me-2"><i class="fas fa-user-circle fa-2x text-primary"></i></div>
                    <div><strong><?= sanitize($user['username']??'') ?></strong>
                    <small class="d-block text-muted"><?= $user['role']==='admin'?'Administrator':'Member' ?></small></div>
                </div>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="dashboard.php"><i class="fas fa-tachometer-alt fa-fw me-2"></i>Dashboard</a>
                <a class="dropdown-item" href="topup.php"><i class="fas fa-wallet fa-fw me-2"></i>Top Up</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-fw me-2 text-danger"></i>Logout</a>
            </div>
        </li>
    </ul>
</nav>
<div class="container-fluid">
<?php else: ?>
<?php endif; ?>
