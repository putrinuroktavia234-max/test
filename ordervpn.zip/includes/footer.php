<?php
/**
 * OrderVPN - Footer Template v2.0
 * Professional Footer with Social Media
 */

$app_name = getSetting('app_name', APP_NAME);
$social = getSocialLinks();
$is_logged_in = isset($_SESSION['user_id']);
$csrf_token = defined('CSRF_TOKEN') ? CSRF_TOKEN : (function_exists('generateCsrfToken') ? generateCsrfToken() : '');
?>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="social-footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5><i class="fas fa-shield-halbed me-2"></i><?= $app_name ?></h5>
                        <p style="opacity:0.8;">Penyedia layanan VPN premium dengan jaringan cepat, aman, dan terpercaya. Akses internet tanpa batas dengan harga terjangkau.</p>
                        <?php if (!empty(getSetting('store_address'))): ?>
                        <p class="mb-0" style="opacity:0.7;"><i class="fas fa-map-marker-alt me-2"></i><?= htmlspecialchars(getSetting('store_address')) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5>Layanan</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2"><a href="dashboard.php"><i class="fas fa-chevron-right me-2" style="font-size:0.7rem;"></i>Dashboard</a></li>
                            <li class="mb-2"><a href="servers.php"><i class="fas fa-chevron-right me-2" style="font-size:0.7rem;"></i>Status Server</a></li>
                            <li class="mb-2"><a href="topup.php"><i class="fas fa-chevron-right me-2" style="font-size:0.7rem;"></i>Top Up Saldo</a></li>
                            <li class="mb-2"><a href="#" data-bs-toggle="modal" data-bs-target="#orderModal"><i class="fas fa-chevron-right me-2" style="font-size:0.7rem;"></i>Order VPN</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <h5>Hubungi Kami</h5>
                        <?php if (!empty(getSetting('store_phone'))): ?>
                        <p class="mb-2" style="opacity:0.8;"><i class="fas fa-phone me-2"></i><?= htmlspecialchars(getSetting('store_phone')) ?></p>
                        <?php endif; ?>
                        <?php if (!empty(getSetting('store_email'))): ?>
                        <p class="mb-2" style="opacity:0.8;"><i class="fas fa-envelope me-2"></i><?= htmlspecialchars(getSetting('store_email')) ?></p>
                        <?php endif; ?>
                        <div class="mt-3">
                            <?php if (!empty($social['whatsapp'])): ?>
                            <a href="https://wa.me/<?= $social['whatsapp'] ?>" target="_blank" class="social-icon whatsapp" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($social['telegram'])): ?>
                            <a href="<?= $social['telegram'] ?>" target="_blank" class="social-icon telegram" title="Telegram"><i class="fab fa-telegram-plane"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($social['instagram'])): ?>
                            <a href="<?= $social['instagram'] ?>" target="_blank" class="social-icon instagram" title="Instagram"><i class="fab fa-instagram"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($social['facebook'])): ?>
                            <a href="<?= $social['facebook'] ?>" target="_blank" class="social-icon facebook" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($social['youtube'])): ?>
                            <a href="<?= $social['youtube'] ?>" target="_blank" class="social-icon youtube" title="YouTube"><i class="fab fa-youtube"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <?= getSetting('footer_text', '&copy; ' . date('Y') . ' ' . $app_name . ' - Premium VPN Service. All rights reserved.') ?>
                    <br><small>Made with <i class="fas fa-heart text-danger"></i> by <a href="https://t.me/YouzinCrabz" class="text-white">Youzin Crabz</a></small>
                </div>
            </div>
        </footer>

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<?php if ($is_logged_in): ?>
<!-- Logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yakin ingin logout?</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">Klik "Logout" untuk mengakhiri sesi anda.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a class="btn btn-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Order Modal -->
<div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-gradient-primary text-white">
                <h5 class="modal-title"><i class="fas fa-shopping-cart me-2"></i>Order VPN Baru</h5>
                <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="orderForm">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Tipe VPN</label>
                            <select class="form-select" name="type" id="orderType" required>
                                <option value="">Pilih Tipe</option>
                                <option value="vmess">VMess</option>
                                <option value="vless">VLess</option>
                                <option value="trojan">Trojan</option>
                                <option value="ssh">SSH</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Server</label>
                            <select class="form-select" name="server_id" id="orderServer" required>
                                <option value="">Pilih Server</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Username</label>
                            <input type="text" class="form-control" name="username" required minlength="3" maxlength="20" placeholder="Buat username...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Durasi (Hari)</label>
                            <select class="form-select" name="days" id="orderDays">
                                <option value="30">30 Hari</option>
                                <option value="60">60 Hari</option>
                                <option value="90">90 Hari</option>
                            </select>
                        </div>
                    </div>
                    <div id="priceDisplay" class="alert alert-info text-center d-none">
                        <small class="d-block text-muted">Total Harga</small>
                        <span class="fw-bold fs-4" id="priceAmount">Rp 0</span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button class="btn btn-primary" onclick="submitOrder()"><i class="fas fa-shopping-cart me-2"></i>Pesan Sekarang</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.4/js/sb-admin-2.min.js"></script>
<script src="assets/js/script.js"></script>

<?php if (getSetting('promo_popup_enabled')=='1' && $is_logged_in): ?>
<script>
$(document).ready(function(){
    if(!localStorage.getItem('promo_shown')){
        setTimeout(function(){
            var m=new bootstrap.Modal(document.getElementById('promoModal'));
            m.show();
            localStorage.setItem('promo_shown','1');
        },2000);
    }
});
</script>
<?php endif; ?>

<script>
$(document).ready(function(){$('.promo-banner-close').on('click',function(){$('.promo-banner').slideUp(300);});});
</script>

</body>
</html>
