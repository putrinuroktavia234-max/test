<?php
/**
 * OrderVPN - Configuration & Core Functions
 * Professional Web Panel for VPN Account Management
 */
session_start();
error_reporting(0);

define('DB_HOST', 'localhost');
define('DB_USER', 'ordervpn');
define('DB_PASS', 'bGo5zufQLvbSEvQh');
define('DB_NAME', 'ordervpn_db');
define('DB_PORT', 3306);

define('APP_NAME', 'OrderVPN');
define('APP_TAGLINE', 'Premium VPN Service');
define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST']);
define('SESSION_LIFETIME', 86400);

define('MIN_TOPUP', 5000);
define('MAX_TOPUP', 1000000);
define('PAYMENT_ACCOUNT', '1234567890');
define('PAYMENT_BANK', 'BCA - PT OrderVPN');
define('PAYMENT_NAME', 'Youzin Crabz');
define('TUNNEL_SCRIPT', '/root/tunnel.sh');
define('SSH_KEY_PATH', '/root/.ssh/id_rsa');
define('SSH_USER', 'root');
define('TG_BOT_TOKEN', '');
define('TG_CHAT_ID', '');

function getDB() {
    static $db = null;
    if ($db === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $db = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="padding:20px;font-family:sans-serif;background:#f8d7da;color:#721c24;border-radius:8px;margin:20px;"><strong>Database Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</div>');
        }
    }
    return $db;
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function generateUUID() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'baru saja';
    if ($diff < 3600) return floor($diff / 60) . ' menit lalu';
    if ($diff < 86400) return floor($diff / 3600) . ' jam lalu';
    if ($diff < 2592000) return floor($diff / 86400) . ' hari lalu';
    return date('d M Y', strtotime($datetime));
}

function sendTelegramNotif($message) {
    if (empty(TG_BOT_TOKEN) || empty(TG_CHAT_ID)) return false;
    $url = "https://api.telegram.org/bot" . TG_BOT_TOKEN . "/sendMessage";
    $data = ['chat_id' => TG_CHAT_ID, 'text' => $message, 'parse_mode' => 'HTML'];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
    ]);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        header('Location: index.php?expired=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['user_role'] !== 'admin') {
        header('Location: dashboard.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isset($_SESSION['user_id'])) return null;
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// ─── Dynamic Settings Loader ──────────────────────────────────────────
// Load settings from app_settings table into global constants
$SETTINGS_CACHE = [];
function loadSettings() {
    global $SETTINGS_CACHE;
    if (!empty($SETTINGS_CACHE)) return $SETTINGS_CACHE;
    try {
        $db = getDB();
        $stmt = $db->query("SELECT setting_key, setting_value FROM app_settings");
        while ($row = $stmt->fetch()) {
            $SETTINGS_CACHE[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Exception $e) {
        // silent
    }
    return $SETTINGS_CACHE;
}

function getSetting($key, $default = '') {
    $settings = loadSettings();
    return $settings[$key] ?? $default;
}

function getSocialLinks() {
    return [
        'whatsapp' => getSetting('whatsapp'),
        'telegram' => getSetting('telegram_channel'),
        'telegram_group' => getSetting('telegram_group'),
        'instagram' => getSetting('instagram'),
        'facebook' => getSetting('facebook'),
        'twitter' => getSetting('twitter'),
        'youtube' => getSetting('youtube'),
        'email' => getSetting('store_email'),
        'phone' => getSetting('store_phone'),
    ];
}
