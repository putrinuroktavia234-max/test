-- OrderVPN Database Schema
-- Professional Web Panel for VPN Account Management

CREATE TABLE IF NOT EXISTS `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL,
    `email` varchar(100) NOT NULL,
    `password` varchar(255) NOT NULL,
    `balance` decimal(15,0) NOT NULL DEFAULT 0,
    `role` enum('user','admin') NOT NULL DEFAULT 'user',
    `ip_address` varchar(45) DEFAULT NULL,
    `last_login` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`),
    UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `servers` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `location` varchar(100) DEFAULT NULL,
    `host` varchar(255) NOT NULL,
    `port` int(11) NOT NULL DEFAULT 22,
    `monthly_price` decimal(15,0) NOT NULL DEFAULT 10000,
    `ip_limit` int(11) NOT NULL DEFAULT 1,
    `quota_limit` int(11) NOT NULL DEFAULT 999,
    `status` enum('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` datetime NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `vpn_accounts` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `server_id` int(11) DEFAULT NULL,
    `type` enum('ssh','vmess','vless','trojan') NOT NULL,
    `username` varchar(50) NOT NULL,
    `uuid` varchar(255) DEFAULT NULL,
    `config_link` text DEFAULT NULL,
    `status` enum('active','expired','deleted') NOT NULL DEFAULT 'active',
    `price` decimal(15,0) NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL DEFAULT current_timestamp(),
    `expired_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `server_id` (`server_id`),
    CONSTRAINT `vpn_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `vpn_accounts_ibfk_2` FOREIGN KEY (`server_id`) REFERENCES `servers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `transactions` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `type` enum('topup','order','refund','adjustment') NOT NULL,
    `amount` decimal(15,0) NOT NULL,
    `status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
    `description` text DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `topup_requests` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `amount` decimal(15,0) NOT NULL,
    `proof_file` varchar(255) DEFAULT NULL,
    `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    `processed_by` int(11) DEFAULT NULL,
    `processed_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    CONSTRAINT `topup_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin user (password: admin123)
INSERT INTO `users` (`username`, `email`, `password`, `balance`, `role`, `created_at`) VALUES
('admin', 'admin@ordervpn.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 100000, 'admin', NOW());

-- Default server
INSERT INTO `servers` (`name`, `location`, `host`, `port`, `monthly_price`, `ip_limit`, `status`) VALUES
('VPS Utama', 'Jakarta, Indonesia', '127.0.0.1', 22, 10000, 1, 'active');
