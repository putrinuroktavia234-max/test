<?php
require_once 'includes/config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// Handle Login
if (isset($_POST['login'])) {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Username dan password harus diisi';
    } else {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['last_activity'] = time();
                
                // Update last login
                $stmt = $db->prepare("UPDATE users SET last_login = NOW(), ip_address = ? WHERE id = ?");
                $stmt->execute([$_SERVER['REMOTE_ADDR'], $user['id']]);
                
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Username atau password salah';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan sistem';
        }
    }
}

// Handle Register
if (isset($_POST['register'])) {
    $username = sanitize($_POST['reg_username'] ?? '');
    $email = sanitize($_POST['reg_email'] ?? '');
    $password = $_POST['reg_password'] ?? '';
    $confirm = $_POST['reg_confirm'] ?? '';
    
    if (empty($username) || empty($email) || empty($password)) {
        $error = 'Semua field harus diisi';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } elseif ($password !== $confirm) {
        $error = 'Password tidak cocok';
    } else {
        try {
            $db = getDB();
            // Check existing
            $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                $error = 'Username atau email sudah terdaftar';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (username, email, password, role, saldo, created_at) VALUES (?, ?, ?, 'user', 0, NOW())");
                $stmt->execute([$username, $email, $hash]);
                $success = 'Registrasi berhasil! Silakan login.';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
        }
    }
}

$expired = isset($_GET['expired']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= APP_NAME ?> - <?= APP_TAGLINE ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .auth-input-group { position: relative; }
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #adb5bd;
            z-index: 10;
        }
        .toggle-password:hover { color: var(--primary); }
    </style>
</head>
<body>
<div class="auth-bg">
    <div class="auth-card animate-fade-in">
        <div class="card-header">
            <div class="brand-icon">
                <i class="fas fa-shield-halved"></i>
            </div>
            <h3><?= APP_NAME ?></h3>
            <p><?= APP_TAGLINE ?></p>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
            <div class="alert alert-danger alert-custom alert-dismissible fade show">
                <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
            <div class="alert alert-success alert-custom alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($expired): ?>
            <div class="alert alert-warning alert-custom alert-dismissible fade show">
                <i class="fas fa-clock me-2"></i>Sesi Anda telah berakhir, silakan login kembali
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <!-- Tabs -->
            <ul class="nav nav-pills nav-justified nav-pills-custom mb-4" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="login-tab" data-bs-toggle="pill" data-bs-target="#login" type="button" role="tab">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="register-tab" data-bs-toggle="pill" data-bs-target="#register" type="button" role="tab">
                        <i class="fas fa-user-plus me-2"></i>Daftar
                    </button>
                </li>
            </ul>
            
            <div class="tab-content">
                <!-- Login Form -->
                <div class="tab-pane fade show active" id="login" role="tabpanel">
                    <form method="POST">
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-user auth-input-icon"></i>
                            <input type="text" class="form-control auth-input" name="username" placeholder="Username atau Email" required>
                        </div>
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-lock auth-input-icon"></i>
                            <input type="password" class="form-control auth-input" id="loginPass" name="password" placeholder="Password" required>
                            <i class="fas fa-eye toggle-password" onclick="togglePass('loginPass', this)"></i>
                        </div>
                        <button type="submit" name="login" class="auth-btn mb-2">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                    </form>
                </div>
                
                <!-- Register Form -->
                <div class="tab-pane fade" id="register" role="tabpanel">
                    <form method="POST">
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-user auth-input-icon"></i>
                            <input type="text" class="form-control auth-input" name="reg_username" placeholder="Username" required minlength="3" maxlength="20">
                        </div>
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-envelope auth-input-icon"></i>
                            <input type="email" class="form-control auth-input" name="reg_email" placeholder="Email" required>
                        </div>
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-lock auth-input-icon"></i>
                            <input type="password" class="form-control auth-input" id="regPass" name="reg_password" placeholder="Password (min 6 karakter)" required minlength="6">
                            <i class="fas fa-eye toggle-password" onclick="togglePass('regPass', this)"></i>
                        </div>
                        <div class="mb-3 auth-input-group">
                            <i class="fas fa-check-circle auth-input-icon"></i>
                            <input type="password" class="form-control auth-input" placeholder="Konfirmasi Password" name="reg_confirm" required>
                        </div>
                        <button type="submit" name="register" class="auth-btn">
                            <i class="fas fa-user-plus me-2"></i>Daftar Sekarang
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="auth-divider">
                <span>&copy; <?= date('Y') ?> <?= APP_NAME ?> - Premium VPN Service</span>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePass(inputId, icon) {
    const input = document.getElementById(inputId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash toggle-password';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye toggle-password';
    }
}
</script>

<?php if (getSetting('promo_popup_enabled') == '1'): ?>
<div class="modal fade" id="promoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content promo-modal-content">
            <div class="modal-header border-0"><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body text-center py-4">
                <div class="promo-popup-icon mb-3"><i class="fas fa-gift fa-3x" style="color:var(--primary-color);"></i></div>
                <h4 class="fw-bold mb-2"><?= htmlspecialchars(getSetting("promo_popup_title", "🎉 Promo Spesial!")) ?></h4>
                <p class="text-muted mb-4"><?= htmlspecialchars(getSetting("promo_popup_message", "")) ?></p>
                <button class="btn btn-primary btn-lg px-5 promo-cta-btn" data-bs-dismiss="modal"><i class="fas fa-check me-2"></i>Dapatkan Promo</button>
            </div>
        </div>
    </div>
</div>
<script>
.ready(function(){
    if(!localStorage.getItem("promo_shown")){
        setTimeout(function(){
            var m=new bootstrap.Modal(document.getElementById("promoModal"));
            m.show();
            localStorage.setItem("promo_shown","1");
        },2000);
    }
});
</script>
<?php endif; ?>
</body>
</html>
