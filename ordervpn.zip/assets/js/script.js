/**
 * OrderVPN - Custom JavaScript
 * Professional Web Panel
 */

$(document).ready(function() {
    // Load servers for order modal
    loadServers();
    
    // Calculate price on days change
    $('#daysSelect, #serverSelect').change(calculatePrice);
    
    // Auto-dismiss alerts
    setTimeout(function() {
        $('.alert-dismissible').alert('close');
    }, 5000);
});

// ========= LOADING OVERLAY =========
function showLoading() {
    $('#loadingOverlay').addClass('active');
}

function hideLoading() {
    $('#loadingOverlay').removeClass('active');
}

// ========= TOAST NOTIFICATION =========
function showToast(message, type = 'success') {
    const bgColor = type === 'success' ? '#1cc88a' : type === 'error' ? '#e74a3b' : '#f6c23e';
    const icon = type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle';
    
    const toast = `
        <div class="toast align-items-center text-white border-0 show animate-fade-in" role="alert" style="background: ${bgColor};">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas ${icon} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    $('#toastContainer').append(toast);
    setTimeout(function() {
        $('#toastContainer .toast:first').remove();
    }, 4000);
}

// ========= SERVER MANAGEMENT =========
function loadServers() {
    $.ajax({
        url: 'api/get_servers.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            if (data.success && data.data.length > 0) {
                let opts = '<option value="">Pilih Server</option>';
                data.data.forEach(function(s) {
                    opts += `<option value="${s.id}" data-price="${s.monthly_price}">${s.name} - ${s.location}</option>`;
                });
                $('#serverSelect').html(opts);
            } else {
                $('#serverSelect').html('<option value="">Tidak ada server tersedia</option>');
            }
        },
        error: function() {
            $('#serverSelect').html('<option value="">Gagal load server</option>');
        }
    });
}

function calculatePrice() {
    const serverId = $('#serverSelect').val();
    const days = parseInt($('#daysSelect').val()) || 30;
    
    if (!serverId) {
        $('#priceDisplay').text('Rp 0');
        return;
    }
    
    const server = $('#serverSelect option:selected');
    const monthlyPrice = parseInt(server.data('price')) || 10000;
    const total = monthlyPrice * Math.ceil(days / 30);
    
    $('#priceDisplay').text('Rp ' + total.toLocaleString('id-ID'));
}

// ========= ORDER VPN =========
function submitOrder() {
    const form = $('#orderForm');
    const data = form.serialize();
    
    if (!form[0].checkValidity()) {
        form[0].reportValidity();
        return;
    }
    
    showLoading();
    
    $.ajax({
        url: 'api/create_order.php',
        method: 'POST',
        data: data,
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast(res.message, 'success');
                $('#orderModal').modal('hide');
                form[0].reset();
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                showToast(res.message || 'Gagal memproses order', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

// ========= DELETE ACCOUNT =========
function deleteAccount(accountId, type) {
    if (!confirm('Yakin ingin menghapus akun ' + type.toUpperCase() + ' ini?')) return;
    
    showLoading();
    
    $.ajax({
        url: 'api/delete_account.php',
        method: 'POST',
        data: {
            id: accountId,
            type: type,
            csrf_token: $('input[name="csrf_token"]').val() || ''
        },
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Akun berhasil dihapus', 'success');
                $('#account-' + accountId).fadeOut(500, function() { $(this).remove(); });
            } else {
                showToast(res.message || 'Gagal menghapus akun', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

// ========= COPY TO CLIPBOARD =========
function copyConfig(elementId) {
    const text = $('#' + elementId).text().trim();
    navigator.clipboard.writeText(text).then(function() {
        showToast('Config berhasil di-copy!', 'success');
    }).catch(function() {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('Config berhasil di-copy!', 'success');
    });
}

// ========= TOPUP MANAGEMENT =========
function submitTopup() {
    const amount = $('#topupAmount').val();
    const proof = $('#topupProof')[0].files[0];
    
    if (!amount || amount < 5000) {
        showToast('Minimal topup Rp 5.000', 'error');
        return;
    }
    if (!proof) {
        showToast('Upload bukti transfer', 'error');
        return;
    }
    
    showLoading();
    
    const formData = new FormData();
    formData.append('amount', amount);
    formData.append('proof', proof);
    formData.append('csrf_token', $('input[name="csrf_token"]').val() || '');
    
    $.ajax({
        url: 'api/topup_request.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Permintaan topup dikirim!', 'success');
                $('#topupForm')[0].reset();
                location.reload();
            } else {
                showToast(res.message || 'Gagal', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

// ========= ADMIN: APPROVE/REJECT TOPUP =========
function approveTopup(id) {
    if (!confirm('Setujui permintaan topup ini?')) return;
    processTopup(id, 'approved');
}

function rejectTopup(id) {
    if (!confirm('Tolak permintaan topup ini?')) return;
    processTopup(id, 'rejected');
}

function processTopup(id, status) {
    showLoading();
    
    $.ajax({
        url: 'api/process_topup.php',
        method: 'POST',
        data: {
            id: id,
            status: status,
            csrf_token: $('input[name="csrf_token"]').val() || ''
        },
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Status topup updated!', 'success');
                location.reload();
            } else {
                showToast(res.message || 'Gagal', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

// ========= ADMIN: MANAGE SERVER =========
function saveServer(id = null) {
    const form = $('#serverForm');
    const data = form.serialize();
    if (id) data += '&server_id=' + id;
    
    showLoading();
    
    $.ajax({
        url: 'api/save_server.php',
        method: 'POST',
        data: data,
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Server saved!', 'success');
                $('#serverModal').modal('hide');
                location.reload();
            } else {
                showToast(res.message || 'Gagal', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

function deleteServer(id) {
    if (!confirm('Hapus server ini?')) return;
    showLoading();
    
    $.ajax({
        url: 'api/delete_server.php',
        method: 'POST',
        data: { id: id, csrf_token: $('input[name="csrf_token"]').val() || '' },
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Server dihapus!', 'success');
                location.reload();
            } else {
                showToast(res.message || 'Gagal', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}

// ========= ADMIN: ADJUST BALANCE =========
function adjustBalance(userId) {
    const amount = prompt('Jumlah penyesuaian saldo (gunakan - untuk minus):', '0');
    if (amount === null || amount === '') return;
    
    showLoading();
    
    $.ajax({
        url: 'api/adjust_balance.php',
        method: 'POST',
        data: {
            user_id: userId,
            amount: amount,
            csrf_token: $('input[name="csrf_token"]').val() || ''
        },
        dataType: 'json',
        success: function(res) {
            hideLoading();
            if (res.success) {
                showToast('Saldo disesuaikan!', 'success');
                location.reload();
            } else {
                showToast(res.message || 'Gagal', 'error');
            }
        },
        error: function() {
            hideLoading();
            showToast('Terjadi kesalahan server', 'error');
        }
    });
}
