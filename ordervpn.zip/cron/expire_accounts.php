<?php
/**
 * OrderVPN - Cron Job: Expire Accounts
 * Run every hour via cron
 */
require_once __DIR__ . '/../includes/config.php';

try {
    $db = getDB();
    
    // Get all expired accounts
    $stmt = $db->prepare("SELECT va.*, u.username as user_name FROM vpn_accounts va JOIN users u ON va.user_id = u.id WHERE va.masa_aktif <= NOW() AND va.status = 'active'");
    $stmt->execute();
    $expired = $stmt->fetchAll();
    
    foreach ($expired as $acc) {
        // Execute tunnel.sh to delete account
        $cmd = escapeshellcmd("bash " . TUNNEL_SCRIPT . " delete " . $acc['type'] . " " . $acc['username']);
        $output = shell_exec($cmd . " 2>&1");
        
        // Update database
        $stmt = $db->prepare("UPDATE vpn_accounts SET status = 'expired' WHERE id = ?");
        $stmt->execute([$acc['id']]);
        
        // Notify via Telegram
        $msg = "⏰ Akun Expired\nUser: {$acc['user_name']}\nTipe: {$acc['type']}\nUsername: {$acc['username']}\nStatus: Auto-deleted";
        sendTelegramNotif($msg);
    }
    
    echo "[" . date('Y-m-d H:i:s') . "] Processed " . count($expired) . " expired accounts\n";
} catch (Exception $e) {
    echo "[" . date('Y-m-d H:i:s') . "] Error: " . $e->getMessage() . "\n";
}
