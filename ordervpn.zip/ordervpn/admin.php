<?php
require_once 'includes/config.php';
requireAdmin();

$db = getDB();
$user_id = $_SESSION['user_id'];

// Get stats
$stmt = $db->query("SELECT COUNT(*) as total_users FROM users");
$total_users = $stmt->fetch()['total_users'];

$stmt = $db->query("SELECT COALESCE(SUM(balance), 0) as total_balance FROM users");
$total_balance = $stmt->fetch()['total_balance'];

$stmt = $db->query("SELECT COALESCE(SUM(amount), 0) as total_revenue FROM transactions WHERE type='order' AND status='completed'");
$total_revenue = $stmt->fetch()['total_revenue'];

$stmt = $db->query("SELECT COUNT(*) as total_orders FROM vpn_accounts");
$total_orders = $stmt->fetch()['total_orders'];

// Get pending topup
$stmt = $db->query("SELECT tr.*, u.username as user_name FROM topup_requests tr JOIN users u ON tr.user_id = u.id WHERE tr.status = 'pending' ORDER BY tr.created_at DESC");
$pending_topups = $stmt->fetchAll();

// Get all users
$stmt = $db->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();

// Get all servers
$stmt = $db->query("SELECT * FROM servers ORDER BY name ASC");
$servers = $stmt->fetchAll();

// Chart data - last 7 days orders
$stmt = $db->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM vpn_accounts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date ASC");
$chartData = $stmt->fetchAll();
$chart_labels = [];
$chart_values = [];
foreach ($chartData as $d) {
    $chart_labels[] = date('d M', strtotime($d['date']));
    $chart_values[] = $d['count'];
}

require_once 'includes/header.php';
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4 animate-fade-in">
    <h1 class="h3 mb-0 text-gray-800">Admin Panel</h1>
</div>

<!-- Stats -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stat-card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-primary">Total User</div>
                        <div class="stat-value text-gray-800"><?= $total_users ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-users fa-3x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stat-card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-success">Total Saldo</div>
                        <div class="stat-value text-gray-800"><?= formatRupiah($total_balance) ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-wallet fa-3x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stat-card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-warning">Revenue</div>
                        <div class="stat-value text-gray-800"><?= formatRupiah($total_revenue) ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-dollar-sign fa-3x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card stat-card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-info">Total Order</div>
                        <div class="stat-value text-gray-800"><?= $total_orders ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-shopping-cart fa-3x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Pending Topups -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-warning"><i class="fas fa-clock me-2"></i>Pending Topup</h6>
        <span class="badge bg-warning badge-custom"><?= count($pending_topups) ?> pending</span>
    </div>
    <div class="card-body">
        <div class="chart-bar"><canvas id="ordersChart" height="100"></canvas></div>
    </div>
    <div class="card-body">
        <?php if (empty($pending_topups)): ?>
        <p class="text-muted text-center py-3">Tidak ada permintaan topup pending</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>User</th><th>Jumlah</th><th>Tanggal</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php foreach ($pending_topups as $t): ?>
                    <tr>
                        <td><?= sanitize($t['user_name']) ?></td>
                        <td><strong><?= formatRupiah($t['amount']) ?></strong></td>
                        <td><?= timeAgo($t['created_at']) ?></td>
                        <td>
                            <?php if ($t['proof_file']): ?>
                            <a href="uploads/bukti/<?= $t['proof_file'] ?>" target="_blank" class="btn btn-sm btn-outline-info me-1"><i class="fas fa-image"></i></a>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-success" onclick="approveTopup(<?= $t['id'] ?>)"><i class="fas fa-check"></i></button>
                            <button class="btn btn-sm btn-danger" onclick="rejectTopup(<?= $t['id'] ?>)"><i class="fas fa-times"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Users Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-users me-2"></i>Users</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>Username</th><th>Email</th><th>Saldo</th><th>Role</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td><strong><?= sanitize($u['username']) ?></strong></td>
                        <td><?= sanitize($u['email']) ?></td>
                        <td><?= formatRupiah($u['balance']) ?></td>
                        <td><span class="badge badge-custom <?= $u['role'] == 'admin' ? 'badge-active' : 'badge-pending' ?>"><?= $u['role'] ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-warning" onclick="adjustBalance(<?= $u['id'] ?>)">
                                <i class="fas fa-coins"></i> Saldo
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Servers Management -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-server me-2"></i>Server Management</h6>
        <button class="btn btn-primary btn-sm" onclick="editServer(0)"><i class="fas fa-plus me-1"></i>Tambah Server</button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>Name</th><th>Location</th><th>Host</th><th>Price</th><th>Status</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php foreach ($servers as $s): ?>
                    <tr>
                        <td><?= sanitize($s['name']) ?></td>
                        <td><?= sanitize($s['location']) ?></td>
                        <td><?= sanitize($s['host']) ?>:<?= $s['port'] ?></td>
                        <td><?= formatRupiah($s['monthly_price']) ?></td>
                        <td><span class="badge badge-custom <?= $s['status'] == 'active' ? 'badge-active' : 'badge-expired' ?>"><?= $s['status'] ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="editServer(<?= $s['id'] ?>)"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteServer(<?= $s['id'] ?>)"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Server Edit Modal -->
<div class="modal fade modal-custom" id="serverModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="serverModalTitle"><i class="fas fa-server me-2"></i>Tambah Server</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="serverForm">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="server_id" id="editServerId" value="0">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Server</label>
                            <input type="text" class="form-control" name="name" id="editServerName" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Lokasi</label>
                            <input type="text" class="form-control" name="location" id="editServerLoc">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Host</label>
                            <input type="text" class="form-control" name="host" id="editServerHost" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Port</label>
                            <input type="number" class="form-control" name="port" id="editServerPort" value="22">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Price/Month</label>
                            <input type="number" class="form-control" name="monthly_price" id="editServerPrice" value="10000">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">IP Limit</label>
                            <input type="number" class="form-control" name="ip_limit" id="editServerIpLimit" value="1">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="editServerStatus">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button class="btn btn-primary" onclick="saveServer()"><i class="fas fa-save me-1"></i>Simpan</button>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

<script>
// Chart
const ctx = document.getElementById('ordersChart');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($chart_labels) ?>,
            datasets: [{
                label: 'Orders',
                data: <?= json_encode($chart_values) ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78,115,223,0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } }
        }
    });
}

function editServer(id) {
    $('#editServerId').val(id);
    if (id === 0) {
        $('#serverModalTitle').html('<i class="fas fa-plus me-2"></i>Tambah Server');
        $('#editServerName, #editServerLoc, #editServerHost').val('');
        $('#editServerPort').val(22);
        $('#editServerPrice').val(10000);
        $('#editServerIpLimit').val(1);
        $('#editServerStatus').val('active');
    } else {
        $('#serverModalTitle').html('<i class="fas fa-edit me-2"></i>Edit Server');
        // Load server data via API
        $.get('api/get_servers.php', function(res) {
            if (res.success) {
                const s = res.data.find(x => x.id == id);
                if (s) {
                    $('#editServerName').val(s.name);
                    $('#editServerLoc').val(s.location);
                    $('#editServerHost').val(s.host);
                    $('#editServerPort').val(s.port);
                    $('#editServerPrice').val(s.monthly_price);
                    $('#editServerIpLimit').val(s.ip_limit);
                    $('#editServerStatus').val(s.status);
                }
            }
        });
    }
    $('#serverModal').modal('show');
}
</script>

<?php require_once 'includes/footer.php'; ?>
