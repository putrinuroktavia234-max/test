<?php
require_once __DIR__ . '/includes/config.php';
$session = requireAdmin();
$db = getDB();

// Handle admin actions
$message = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Approve/Reject topup
    if ($action === 'approve_topup') {
        $topupId = (int)$_POST['topup_id'];
        $stmt = $db->prepare("SELECT * FROM topup_requests WHERE id = ?");
        $stmt->execute([$topupId]);
        $topup = $stmt->fetch();
        
        if ($topup && $topup['status'] === 'pending') {
            $db->prepare("UPDATE topup_requests SET status='approved', processed_at=NOW(), admin_note=? WHERE id=?")->execute([$_POST['note']??'', $topupId]);
            $db->prepare("UPDATE users SET saldo = saldo + ? WHERE id=?")->execute([$topup['amount'], $topup['user_id']]);
            $db->prepare("INSERT INTO transactions (user_id, type, amount, keterangan) VALUES (?,?,?,?)")
               ->execute([$topup['user_id'], 'topup', $topup['amount'], 'Topup disetujui admin']);
            $message = 'Topup berhasil disetujui!';
            $msgType = 'success';
        }
    }
    
    if ($action === 'reject_topup') {
        $topupId = (int)$_POST['topup_id'];
        $db->prepare("UPDATE topup_requests SET status='rejected', processed_at=NOW(), admin_note=? WHERE id=?")->execute([$_POST['note']??'Ditolak admin', $topupId]);
        $message = 'Topup ditolak.';
        $msgType = 'error';
    }
    
    // Add/Edit Server
    if ($action === 'save_server') {
        $fields = [
            sanitize($_POST['nama_server']),
            sanitize($_POST['code_server']),
            sanitize($_POST['lokasi']),
            (int)$_POST['harga_hari'],
            (int)$_POST['harga_bulan'],
            (int)$_POST['ip_limit'],
            (int)$_POST['quota_limit'],
            sanitize($_POST['host']),
            (int)$_POST['port'],
            sanitize($_POST['status']),
        ];
        $serverId = (int)($_POST['server_id'] ?? 0);
        if ($serverId) {
            $db->prepare("UPDATE servers SET nama_server=?,code_server=?,lokasi=?,harga_hari=?,harga_bulan=?,ip_limit=?,quota_limit=?,host=?,port=?,status=? WHERE id=?")->execute([...$fields, $serverId]);
            $message = 'Server berhasil diupdate!';
        } else {
            $db->prepare("INSERT INTO servers (nama_server,code_server,lokasi,harga_hari,harga_bulan,ip_limit,quota_limit,host,port,status) VALUES (?,?,?,?,?,?,?,?,?,?)")->execute($fields);
            $message = 'Server berhasil ditambahkan!';
        }
        $msgType = 'success';
    }
    
    if ($action === 'delete_server') {
        $db->prepare("DELETE FROM servers WHERE id=?")->execute([(int)$_POST['server_id']]);
        $message = 'Server dihapus.'; $msgType = 'success';
    }
    
    if ($action === 'adjust_saldo') {
        $userId = (int)$_POST['user_id'];
        $amount = (int)$_POST['amount'];
        $type = $_POST['saldo_type']; // add/sub
        $note = sanitize($_POST['note'] ?? 'Penyesuaian saldo admin');
        if ($type === 'add') {
            $db->prepare("UPDATE users SET saldo = saldo + ? WHERE id=?")->execute([$amount, $userId]);
            $db->prepare("INSERT INTO transactions (user_id, type, amount, keterangan) VALUES (?,?,?,?)")->execute([$userId, 'topup', $amount, $note]);
        } else {
            $db->prepare("UPDATE users SET saldo = GREATEST(0, saldo - ?) WHERE id=?")->execute([$amount, $userId]);
            $db->prepare("INSERT INTO transactions (user_id, type, amount, keterangan) VALUES (?,?,?,?)")->execute([$userId, 'order', $amount, $note]);
        }
        $message = 'Saldo berhasil disesuaikan!'; $msgType = 'success';
    }
}

// Get data
$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
$servers = $db->query("SELECT * FROM servers ORDER BY id ASC")->fetchAll();
$pendingTopups = $db->query("SELECT tr.*, u.username FROM topup_requests tr JOIN users u ON tr.user_id = u.id WHERE tr.status = 'pending' ORDER BY tr.created_at ASC")->fetchAll();
$allTopups = $db->query("SELECT tr.*, u.username FROM topup_requests tr JOIN users u ON tr.user_id = u.id ORDER BY tr.created_at DESC LIMIT 30")->fetchAll();
$stats = $db->query("SELECT COUNT(*) as total_users, SUM(saldo) as total_saldo FROM users WHERE role='user'")->fetch();
$orderStats = $db->query("SELECT COUNT(*) as total_orders, SUM(harga_total) as total_revenue FROM vpn_accounts")->fetch();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root { --blue: #2563eb; --bg: #0f172a; --card: #1e293b; --border: #334155; --text: #f1f5f9; --muted: #94a3b8; --radius: 12px; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
.navbar { background: var(--card); border-bottom: 1px solid var(--border); padding: 0 1.5rem; height: 60px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; }
.nav-brand { font-weight: 700; font-size: 1.1rem; }
.nav-links { display: flex; gap: 0.5rem; }
.nav-links button { background: transparent; border: none; color: var(--muted); padding: 0.5rem 0.9rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: 500; font-family: inherit; transition: all 0.2s; }
.nav-links button.active, .nav-links button:hover { background: #334155; color: var(--text); }
.container { max-width: 1200px; margin: 0 auto; padding: 1.5rem; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.stat-card { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.25rem; }
.stat-label { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.5rem; }
.stat-value { font-size: 1.5rem; font-weight: 700; }
.stat-value.green { color: #4ade80; } .stat-value.blue { color: #60a5fa; } .stat-value.yellow { color: #fbbf24; }
.tab-content { display: none; } .tab-content.active { display: block; }
.card { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; margin-bottom: 1.5rem; }
.card-head { padding: 1rem 1.25rem; background: #162032; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; font-weight: 700; font-size: 0.95rem; }
table { width: 100%; border-collapse: collapse; }
th { padding: 0.6rem 0.75rem; font-size: 0.75rem; font-weight: 600; color: var(--muted); background: #162032; border-bottom: 1px solid var(--border); text-align: left; }
td { padding: 0.75rem; font-size: 0.85rem; border-bottom: 1px solid #1e293b; vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: #1e2d45; }
.badge { display: inline-flex; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
.badge-pending { background: #78350f44; color: #fcd34d; } .badge-approved { background: #14532d44; color: #4ade80; } .badge-rejected { background: #7f1d1d44; color: #f87171; }
.badge-ready { background: #14532d44; color: #4ade80; } .badge-maintenance { background: #78350f44; color: #fcd34d; } .badge-offline { background: #7f1d1d44; color: #f87171; }
.btn { padding: 0.4rem 0.9rem; border-radius: 8px; font-size: 0.8rem; font-weight: 600; cursor: pointer; font-family: inherit; border: none; transition: all 0.2s; display: inline-flex; align-items: center; gap: 0.3rem; }
.btn-sm { padding: 0.3rem 0.65rem; font-size: 0.75rem; }
.btn-primary { background: var(--blue); color: white; }
.btn-success { background: #14532d44; color: #4ade80; border: 1px solid #14532d55; }
.btn-danger { background: #7f1d1d33; color: #fca5a5; border: 1px solid #7f1d1d55; }
.btn-warning { background: #78350f44; color: #fcd34d; border: 1px solid #78350f55; }
.alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.25rem; font-size: 0.875rem; }
.alert-error { background: #7f1d1d22; border: 1px solid #7f1d1d; color: #fca5a5; }
.alert-success { background: #14532d22; border: 1px solid #14532d; color: #86efac; }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
.form-group { margin-bottom: 1rem; }
label { display: block; font-size: 0.8rem; font-weight: 600; color: var(--muted); margin-bottom: 0.4rem; }
input[type="text"],input[type="number"],select { width: 100%; padding: 0.65rem 0.85rem; background: #0f172a; border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.875rem; font-family: inherit; outline: none; }
input:focus,select:focus { border-color: var(--blue); }
select option { background: #1e293b; }
.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 200; align-items: center; justify-content: center; padding: 1rem; }
.modal-overlay.show { display: flex; }
.modal { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.75rem; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; }
.modal h3 { font-weight: 700; font-size: 1rem; margin-bottom: 1.25rem; }
.modal-close { float: right; background: none; border: none; color: var(--muted); font-size: 1.5rem; cursor: pointer; }
.btn-full { width: 100%; padding: 0.75rem; background: var(--blue); color: white; border: none; border-radius: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer; font-family: inherit; margin-top: 0.5rem; }
.pending-count { background: #dc2626; color: white; border-radius: 50%; width: 20px; height: 20px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 700; margin-left: 4px; }
</style>
</head>
<body>
<nav class="navbar">
  <div class="nav-brand">⚙️ Admin Panel - <?= APP_NAME ?></div>
  <div class="nav-links">
    <button class="active" onclick="showTab('overview', this)">📊 Overview</button>
    <button onclick="showTab('topups', this)">💰 Topup <?php if (count($pendingTopups)>0): ?><span class="pending-count"><?= count($pendingTopups) ?></span><?php endif; ?></button>
    <button onclick="showTab('users', this)">👥 Users</button>
    <button onclick="showTab('servers', this)">🖥️ Server</button>
  </div>
  <a href="/dashboard.php" style="color:var(--muted);text-decoration:none;font-size:0.875rem;">← User Panel</a>
</nav>

<div class="container">
  <?php if ($message): ?>
  <div class="alert alert-<?= $msgType ?>"><?= $message ?></div>
  <?php endif; ?>
  
  <!-- OVERVIEW TAB -->
  <div class="tab-content active" id="tab-overview">
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-label">Total Users</div><div class="stat-value blue"><?= $stats['total_users'] ?></div></div>
      <div class="stat-card"><div class="stat-label">Total Saldo User</div><div class="stat-value green"><?= formatRupiah($stats['total_saldo'] ?? 0) ?></div></div>
      <div class="stat-card"><div class="stat-label">Total Orders</div><div class="stat-value yellow"><?= $orderStats['total_orders'] ?></div></div>
      <div class="stat-card"><div class="stat-label">Total Revenue</div><div class="stat-value green"><?= formatRupiah($orderStats['total_revenue'] ?? 0) ?></div></div>
      <div class="stat-card"><div class="stat-label">Pending Topup</div><div class="stat-value" style="color:#f87171;"><?= count($pendingTopups) ?></div></div>
      <div class="stat-card"><div class="stat-label">Servers Aktif</div><div class="stat-value blue"><?= count(array_filter($servers, fn($s) => $s['status']==='ready')) ?></div></div>
    </div>
  </div>
  
  <!-- TOPUP TAB -->
  <div class="tab-content" id="tab-topups">
    <?php if (count($pendingTopups) > 0): ?>
    <div class="card">
      <div class="card-head">⏳ Request Topup Pending (<?= count($pendingTopups) ?>)</div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Tanggal</th><th>User</th><th>Jumlah</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($pendingTopups as $tp): ?>
          <tr>
            <td style="font-size:0.8rem;"><?= date('d/m/Y H:i', strtotime($tp['created_at'])) ?></td>
            <td style="font-weight:600;">@<?= htmlspecialchars($tp['username']) ?></td>
            <td style="font-weight:700;color:#4ade80;"><?= formatRupiah($tp['amount']) ?></td>
            <td>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="approve_topup">
                <input type="hidden" name="topup_id" value="<?= $tp['id'] ?>">
                <input type="hidden" name="note" value="Disetujui admin">
                <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Setujui topup ini?')">✅ Setujui</button>
              </form>
              <form method="POST" style="display:inline;margin-left:4px;">
                <input type="hidden" name="action" value="reject_topup">
                <input type="hidden" name="topup_id" value="<?= $tp['id'] ?>">
                <input type="hidden" name="note" value="Ditolak admin">
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tolak topup ini?')">❌ Tolak</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
    <?php endif; ?>
    
    <div class="card">
      <div class="card-head">📋 Semua Request Topup</div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Tanggal</th><th>User</th><th>Jumlah</th><th>Status</th><th>Catatan</th></tr></thead>
        <tbody>
          <?php foreach ($allTopups as $tp): ?>
          <tr>
            <td style="font-size:0.8rem;"><?= date('d/m/Y H:i', strtotime($tp['created_at'])) ?></td>
            <td>@<?= htmlspecialchars($tp['username']) ?></td>
            <td style="font-weight:600;color:#60a5fa;"><?= formatRupiah($tp['amount']) ?></td>
            <td><span class="badge badge-<?= $tp['status'] ?>"><?= $tp['status'] ?></span></td>
            <td style="font-size:0.8rem;color:var(--muted);"><?= htmlspecialchars($tp['admin_note'] ?? '') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
  
  <!-- USERS TAB -->
  <div class="tab-content" id="tab-users">
    <div class="card">
      <div class="card-head">👥 Daftar User</div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Username</th><th>Email</th><th>Saldo</th><th>Role</th><th>Daftar</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($users as $u): ?>
          <tr>
            <td style="font-weight:600;">@<?= htmlspecialchars($u['username']) ?></td>
            <td style="font-size:0.8rem;color:var(--muted);"><?= htmlspecialchars($u['email']) ?></td>
            <td style="font-weight:600;color:#4ade80;"><?= formatRupiah($u['saldo']) ?></td>
            <td><span class="badge" style="background:<?= $u['role']==='admin'?'#1e3a8a44':'#334155' ?>;color:<?= $u['role']==='admin'?'#93c5fd':'#94a3b8' ?>;"><?= $u['role'] ?></span></td>
            <td style="font-size:0.8rem;color:var(--muted);"><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
            <td>
              <?php if ($u['role'] !== 'admin'): ?>
              <button class="btn btn-warning btn-sm" onclick="openAdjustSaldo(<?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">💰 Saldo</button>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
  
  <!-- SERVERS TAB -->
  <div class="tab-content" id="tab-servers">
    <div class="card">
      <div class="card-head">
        🖥️ Daftar Server
        <button class="btn btn-primary btn-sm" onclick="openAddServer()">+ Tambah Server</button>
      </div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Nama</th><th>Code</th><th>Lokasi</th><th>Harga/Hari</th><th>Host</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($servers as $srv): ?>
          <tr>
            <td style="font-weight:600;"><?= htmlspecialchars($srv['nama_server']) ?></td>
            <td style="font-family:monospace;"><?= htmlspecialchars($srv['code_server']) ?></td>
            <td style="font-size:0.8rem;"><?= htmlspecialchars($srv['lokasi']) ?></td>
            <td style="color:#60a5fa;font-weight:600;"><?= formatRupiah($srv['harga_hari']) ?></td>
            <td style="font-family:monospace;font-size:0.8rem;"><?= htmlspecialchars($srv['host']) ?></td>
            <td><span class="badge badge-<?= $srv['status'] ?>"><?= $srv['status'] ?></span></td>
            <td>
              <button class="btn btn-warning btn-sm" onclick="openEditServer(<?= htmlspecialchars(json_encode($srv)) ?>)">✏️</button>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="delete_server">
                <input type="hidden" name="server_id" value="<?= $srv['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus server ini?')">🗑️</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</div>

<!-- Adjust Saldo Modal -->
<div class="modal-overlay" id="saldoModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('saldoModal')">×</button>
    <h3>💰 Penyesuaian Saldo - <span id="saldoUsername"></span></h3>
    <form method="POST">
      <input type="hidden" name="action" value="adjust_saldo">
      <input type="hidden" name="user_id" id="saldoUserId">
      <div class="form-group">
        <label>Tipe</label>
        <select name="saldo_type">
          <option value="add">➕ Tambah Saldo</option>
          <option value="sub">➖ Kurangi Saldo</option>
        </select>
      </div>
      <div class="form-group">
        <label>Jumlah (Rp)</label>
        <input type="number" name="amount" placeholder="10000" min="1" required>
      </div>
      <div class="form-group">
        <label>Catatan</label>
        <input type="text" name="note" placeholder="Keterangan penyesuaian">
      </div>
      <button type="submit" class="btn-full">Simpan</button>
    </form>
  </div>
</div>

<!-- Server Form Modal -->
<div class="modal-overlay" id="serverModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('serverModal')">×</button>
    <h3 id="serverModalTitle">➕ Tambah Server</h3>
    <form method="POST">
      <input type="hidden" name="action" value="save_server">
      <input type="hidden" name="server_id" id="editServerId" value="0">
      <div class="form-grid">
        <div class="form-group">
          <label>Nama Server</label>
          <input type="text" name="nama_server" id="f_nama" placeholder="ANYM NETWORK" required>
        </div>
        <div class="form-group">
          <label>Code Server</label>
          <input type="text" name="code_server" id="f_code" placeholder="vip1" required>
        </div>
        <div class="form-group">
          <label>Lokasi</label>
          <input type="text" name="lokasi" id="f_lokasi" placeholder="Indonesia" required>
        </div>
        <div class="form-group">
          <label>Host / IP</label>
          <input type="text" name="host" id="f_host" placeholder="103.x.x.x" required>
        </div>
        <div class="form-group">
          <label>Port SSH</label>
          <input type="number" name="port" id="f_port" value="22" required>
        </div>
        <div class="form-group">
          <label>Harga per Hari (Rp)</label>
          <input type="number" name="harga_hari" id="f_hhari" placeholder="300" required>
        </div>
        <div class="form-group">
          <label>Harga per Bulan (Rp)</label>
          <input type="number" name="harga_bulan" id="f_hbulan" placeholder="9000" required>
        </div>
        <div class="form-group">
          <label>IP Limit</label>
          <input type="number" name="ip_limit" id="f_iplimit" value="2">
        </div>
        <div class="form-group">
          <label>Quota Limit (GB)</label>
          <input type="number" name="quota_limit" id="f_quota" value="9999">
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status" id="f_status">
            <option value="ready">ready</option>
            <option value="maintenance">maintenance</option>
            <option value="offline">offline</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn-full">💾 Simpan Server</button>
    </form>
  </div>
</div>

<script>
function showTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.nav-links button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
}
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
function openAdjustSaldo(id, username) {
  document.getElementById('saldoUserId').value = id;
  document.getElementById('saldoUsername').textContent = '@' + username;
  document.getElementById('saldoModal').classList.add('show');
}
function openAddServer() {
  document.getElementById('serverModalTitle').textContent = '➕ Tambah Server';
  document.getElementById('editServerId').value = 0;
  ['f_nama','f_code','f_lokasi','f_host'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('f_port').value = 22;
  document.getElementById('f_hhari').value = '';
  document.getElementById('f_hbulan').value = '';
  document.getElementById('f_iplimit').value = 2;
  document.getElementById('f_quota').value = 9999;
  document.getElementById('f_status').value = 'ready';
  document.getElementById('serverModal').classList.add('show');
}
function openEditServer(srv) {
  document.getElementById('serverModalTitle').textContent = '✏️ Edit Server';
  document.getElementById('editServerId').value = srv.id;
  document.getElementById('f_nama').value = srv.nama_server;
  document.getElementById('f_code').value = srv.code_server;
  document.getElementById('f_lokasi').value = srv.lokasi;
  document.getElementById('f_host').value = srv.host;
  document.getElementById('f_port').value = srv.port;
  document.getElementById('f_hhari').value = srv.harga_hari;
  document.getElementById('f_hbulan').value = srv.harga_bulan;
  document.getElementById('f_iplimit').value = srv.ip_limit;
  document.getElementById('f_quota').value = srv.quota_limit;
  document.getElementById('f_status').value = srv.status;
  document.getElementById('serverModal').classList.add('show');
}
document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', function(e) { if(e.target===this) this.classList.remove('show'); });
});
</script>
</body>
</html>
