# 🛡️ OrderVPN - VPN Ordering Management System

Website manajemen order VPN berbasis PHP + MySQL yang terintegrasi dengan script tunnel.sh.

---

## 📁 Struktur File

```
ordervpn/
├── index.php               ← Halaman login/register
├── dashboard.php           ← Dashboard user
├── servers.php             ← Pilih server & form order
├── topup.php               ← Isi saldo
├── admin.php               ← Panel admin (approve topup, manage server)
├── logout.php              ← Logout
├── .htaccess               ← Security & rewrite rules
├── database.sql            ← Script database MySQL
├── includes/
│   ├── config.php          ← Konfigurasi DB, konstanta, helper functions
│   └── vpn_manager.php     ← Integrasi SSH ke tunnel.sh
├── api/
│   ├── create_order.php    ← API buat order VPN
│   └── delete_account.php  ← API hapus akun VPN
└── cron/
    └── expire_accounts.php ← Script expired akun otomatis
```

---

## ⚡ Cara Instalasi

### 1. Persiapan Server
```bash
# Install LAMP/LEMP stack
apt update
apt install -y apache2 mysql-server php php-mysql php-curl php-mbstring

# Atau Nginx
apt install -y nginx mysql-server php-fpm php-mysql php-curl
```

### 2. Upload File
```bash
# Copy ke web root
cp -r ordervpn/ /var/www/html/ordervpn/

# Set permissions
chown -R www-data:www-data /var/www/html/ordervpn/
chmod -R 755 /var/www/html/ordervpn/
```

### 3. Setup Database
```bash
mysql -u root -p < /var/www/html/ordervpn/database.sql
```

### 4. Edit Konfigurasi
Edit file `includes/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // ← ganti
define('DB_PASS', 'your_password'); // ← ganti
define('DB_NAME', 'ordervpn_db');

define('APP_URL', 'https://domain-kamu.com'); // ← ganti

// Rekening topup
define('BANK_NAME', 'BCA');
define('BANK_ACCOUNT', '1234567890'); // ← ganti
define('BANK_HOLDER', 'Nama Kamu');   // ← ganti

// Path tunnel.sh kamu
define('TUNNEL_SCRIPT', '/root/tunnel.sh'); // ← sesuaikan

// Telegram notif (opsional)
define('TG_BOT_TOKEN', 'your_bot_token');
define('TG_CHAT_ID', 'your_chat_id');
```

### 5. Setup SSH Key (untuk integrasi tunnel.sh)
```bash
# Generate SSH key di server web
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa -N ""

# Copy public key ke masing-masing VPS
ssh-copy-id -i /root/.ssh/id_rsa.pub root@IP_VPS_KAMU

# Test koneksi
ssh -i /root/.ssh/id_rsa root@IP_VPS_KAMU 'echo OK'
```

### 6. Setup VirtualHost Apache
```apache
<VirtualHost *:80>
    ServerName domain-kamu.com
    DocumentRoot /var/www/html/ordervpn
    
    <Directory /var/www/html/ordervpn>
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/ordervpn_error.log
    CustomLog ${APACHE_LOG_DIR}/ordervpn_access.log combined
</VirtualHost>
```
```bash
a2ensite ordervpn.conf
a2enmod rewrite
systemctl restart apache2
```

### 7. Setup Nginx (alternatif)
```nginx
server {
    listen 80;
    server_name domain-kamu.com;
    root /var/www/html/ordervpn;
    index index.php;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    location ~ /includes/ { deny all; }
    location ~ /cron/     { deny all; }
}
```

### 8. Setup Cron Job (auto expire akun)
```bash
crontab -e

# Tambahkan baris ini (setiap hari jam 01:00)
0 1 * * * php /var/www/html/ordervpn/cron/expire_accounts.php >> /var/log/ordervpn_cron.log 2>&1
```

---

## 🔧 Integrasi tunnel.sh

File `includes/vpn_manager.php` akan SSH ke VPS dan menjalankan perintah sesuai format:

```bash
# Yang akan dijalankan otomatis:
bash /root/tunnel.sh add-vmess USERNAME DAYS QUOTA
bash /root/tunnel.sh add-vless USERNAME DAYS QUOTA
bash /root/tunnel.sh add-trojan USERNAME DAYS QUOTA
bash /root/tunnel.sh del-vmess USERNAME
```

**Sesuaikan dengan format perintah tunnel.sh kamu** di fungsi `createAccount()` pada `vpn_manager.php`.

---

## 👤 Akun Default Admin
- **URL Login:** `http://domain-kamu.com/`
- **Username:** `admin`
- **Password:** `password`

⚠️ **GANTI PASSWORD ADMIN SETELAH INSTALL!**
```sql
UPDATE users SET password = '$2y$10$...' WHERE username = 'admin';
-- atau buat hash baru:
-- php -r "echo password_hash('passwordbaru', PASSWORD_BCRYPT);"
```

---

## 🌟 Fitur

- ✅ Login / Register user
- ✅ Dashboard user dengan stats akun
- ✅ List server dengan detail lengkap
- ✅ Form order VPN (VMess, VLess, Trojan)
- ✅ Kalkulasi harga otomatis
- ✅ Sistem saldo dan deduct otomatis
- ✅ Topup saldo dengan konfirmasi admin
- ✅ Admin panel (approve topup, manage server, adjust saldo)
- ✅ Riwayat transaksi
- ✅ Config link (bisa di-copy)
- ✅ Auto expire akun via cron
- ✅ Integrasi SSH ke tunnel.sh
- ✅ Notifikasi Telegram (opsional)
- ✅ Responsive mobile

---

## ⚠️ Catatan Penting

1. Pastikan PHP >= 7.4
2. Aktifkan ekstensi: `pdo_mysql`, `curl`, `mbstring`
3. Jika server web dan VPS berbeda, pastikan SSH key sudah dikonfigurasi
4. Gunakan HTTPS (SSL) untuk keamanan — install Certbot/Let's Encrypt
5. Backup database secara berkala

```bash
# Install SSL Certbot
apt install certbot python3-certbot-apache -y
certbot --apache -d domain-kamu.com
```
