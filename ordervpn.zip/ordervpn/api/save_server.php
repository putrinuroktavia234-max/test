<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$id = intval($_POST['server_id'] ?? 0);
$name = sanitize($_POST['name'] ?? '');
$location = sanitize($_POST['location'] ?? '');
$host = sanitize($_POST['host'] ?? '');
$port = intval($_POST['port'] ?? 22);
$monthly_price = intval($_POST['monthly_price'] ?? 10000);
$ip_limit = intval($_POST['ip_limit'] ?? 1);
$status = $_POST['status'] ?? 'active';

if (empty($name) || empty($host)) {
    echo json_encode(['success' => false, 'message' => 'Nama dan host harus diisi']);
    exit;
}

try {
    $db = getDB();
    
    if ($id > 0) {
        $stmt = $db->prepare("UPDATE servers SET name=?, location=?, host=?, port=?, monthly_price=?, ip_limit=?, status=? WHERE id=?");
        $stmt->execute([$name, $location, $host, $port, $monthly_price, $ip_limit, $status, $id]);
    } else {
        $stmt = $db->prepare("INSERT INTO servers (name, location, host, port, monthly_price, ip_limit, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $location, $host, $port, $monthly_price, $ip_limit, $status]);
    }
    
    echo json_encode(['success' => true, 'message' => 'Server saved']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
