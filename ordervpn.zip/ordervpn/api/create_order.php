<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/vpn_manager.php';

header('Content-Type: application/json');
$session = requireLogin();
$userId = $session['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']); exit;
}

$serverId = (int)($data['server_id'] ?? 0);
$tipe = strtolower(sanitize($data['tipe'] ?? ''));
$remarks = sanitize($data['remarks'] ?? '');
$days = (int)($data['days'] ?? 0);

// Validate
if (!in_array($tipe, ['vmess', 'vless', 'trojan', 'ssh'])) {
    echo json_encode(['success' => false, 'message' => 'Tipe VPN tidak valid']); exit;
}
if (empty($remarks) || strlen($remarks) < 3) {
    echo json_encode(['success' => false, 'message' => 'Nama VPN minimal 3 karakter']); exit;
}
if ($days < 1 || $days > 360) {
    echo json_encode(['success' => false, 'message' => 'Masa aktif harus 1-360 hari']); exit;
}

$db = getDB();

// Get server
$stmtSrv = $db->prepare("SELECT * FROM servers WHERE id = ? AND status = 'ready'");
$stmtSrv->execute([$serverId]);
$server = $stmtSrv->fetch();
if (!$server) {
    echo json_encode(['success' => false, 'message' => 'Server tidak ditemukan atau sedang maintenance']); exit;
}

// Get user
$stmtUser = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmtUser->execute([$userId]);
$user = $stmtUser->fetch();

// Calculate price
$total = $server['harga_hari'] * $days;

if ($user['saldo'] < $total) {
    echo json_encode(['success' => false, 'message' => 'Saldo tidak mencukupi. Saldo: ' . formatRupiah($user['saldo']) . ', Dibutuhkan: ' . formatRupiah($total)]); exit;
}

// Check username uniqueness on server
$checkUser = $db->prepare("SELECT id FROM vpn_accounts WHERE server_id = ? AND username = ? AND status = 'active'");
$checkUser->execute([$serverId, $remarks]);
if ($checkUser->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Nama VPN sudah digunakan di server ini, coba nama lain']); exit;
}

// Generate UUID
$uuid = generateUUID();
$expDate = date('Y-m-d', strtotime("+{$days} days"));
$linkConfig = null;

// Try to create account via SSH (if configured)
$result = ['success' => false];
if (!empty($server['host']) && $server['host'] !== '103.1.1.1') {
    try {
        $result = VPNManager::createAccount($server, $tipe, $remarks, $days);
        if ($result['success']) {
            $linkConfig = $result['link_config'];
            $uuid = $result['uuid'] ?? $uuid;
        }
    } catch (Exception $e) {
        // Fallback to demo mode
        $result['success'] = false;
    }
}

// If SSH failed or demo mode, generate config locally
if (!$result['success']) {
    $linkConfig = VPNManager::generateDemoConfig($server, $tipe, $remarks, $uuid);
    // In production, you can fail here instead of using demo:
    // echo json_encode(['success' => false, 'message' => 'Gagal membuat akun di server: ' . ($result['message']??'')]); exit;
}

// Begin transaction
$db->beginTransaction();
try {
    // Deduct saldo
    $db->prepare("UPDATE users SET saldo = saldo - ? WHERE id = ? AND saldo >= ?")->execute([$total, $userId, $total]);
    
    // Save VPN account
    $db->prepare("INSERT INTO vpn_accounts (user_id, server_id, tipe, username, remarks, uuid, link_config, masa_aktif, days_ordered, harga_total, status) VALUES (?,?,?,?,?,?,?,?,?,?,'active')")
       ->execute([$userId, $serverId, $tipe, $remarks, $remarks, $uuid, $linkConfig, $expDate, $days, $total]);
    
    $vpnId = $db->lastInsertId();
    
    // Save transaction
    $db->prepare("INSERT INTO transactions (user_id, type, amount, keterangan, status) VALUES (?,?,?,?,'success')")
       ->execute([$userId, 'order', $total, "Order VPN {$tipe} - {$server['nama_server']} - {$days} hari"]);
    
    $db->commit();
    
    // Send Telegram notification
    sendTelegramNotif("🔔 <b>Order VPN Baru</b>\nUser: @{$user['username']}\nServer: {$server['nama_server']}\nTipe: " . strtoupper($tipe) . "\nRemarkas: {$remarks}\nMasa: {$days} hari\nTotal: " . formatRupiah($total));
    
    echo json_encode([
        'success' => true,
        'message' => 'Order berhasil!',
        'vpn_id' => $vpnId,
        'link_config' => $linkConfig,
        'expired' => $expDate,
    ]);

} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan sistem: ' . $e->getMessage()]);
}
