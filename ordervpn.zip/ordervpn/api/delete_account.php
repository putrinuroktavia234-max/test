<?php
// api/delete_account.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/vpn_manager.php';

header('Content-Type: application/json');
$session = requireLogin();
$userId = $session['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$accId = (int)($data['id'] ?? 0);

$db = getDB();

// Get account (must belong to current user or admin)
$stmt = $db->prepare("SELECT va.*, s.host, s.port, s.ssh_user FROM vpn_accounts va JOIN servers s ON va.server_id = s.id WHERE va.id = ?");
$stmt->execute([$accId]);
$acc = $stmt->fetch();

if (!$acc) {
    echo json_encode(['success' => false, 'message' => 'Akun tidak ditemukan']); exit;
}

$userStmt = $db->prepare("SELECT role FROM users WHERE id = ?");
$userStmt->execute([$userId]);
$currentUser = $userStmt->fetch();

if ($acc['user_id'] != $userId && $currentUser['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Tidak diizinkan']); exit;
}

// Delete from server via SSH (optional, won't fail if SSH unavailable)
VPNManager::deleteAccount($acc, $acc['tipe'], $acc['username']);

// Mark as suspended in DB
$db->prepare("UPDATE vpn_accounts SET status = 'suspended' WHERE id = ?")->execute([$accId]);

echo json_encode(['success' => true, 'message' => 'Akun berhasil dihapus']);
