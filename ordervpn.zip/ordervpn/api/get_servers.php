<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

try {
    $db = getDB();
    $stmt = $db->query("SELECT id, name, location, monthly_price, ip_limit, host, port, status FROM servers WHERE status = 'active' ORDER BY name ASC");
    $servers = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $servers]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
