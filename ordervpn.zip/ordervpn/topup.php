<?php
require_once 'includes/config.php';
requireLogin();

$db = getDB();
$user_id = $_SESSION['user_id'];

// Get user topup requests
$stmt = $db->prepare("SELECT * FROM topup_requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$topups = $stmt->fetchAll();

// Get transaction history
$stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4 animate-fade-in">
    <h1 class="h3 mb-0 text-gray-800">Top Up Saldo</h1>
</div>

<div class="row">
    <div class="col-lg-5">
        <div class="card shadow mb-4 animate-fade-in animate-delay-1">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-credit-card me-2"></i>Form Top Up
                </h6>
            </div>
            <div class="card-body">
                <div class="alert alert-info alert-custom">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Transfer ke rekening:</strong><br>
                    <?= PAYMENT_BANK ?><br>
                    No. Rek: <strong><?= PAYMENT_ACCOUNT ?></strong><br>
                    A.n: <strong><?= PAYMENT_NAME ?></strong>
                </div>
                
                <form id="topupForm" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="mb-3">
                        <label class="form-label fw600">Jumlah Top Up (Rp)</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" class="form-control" id="topupAmount" name="amount" 
                                   min="<?= MIN_TOPUP ?>" max="<?= MAX_TOPUP ?>" step="1000" 
                                   placeholder="Min Rp <?= number_format(MIN_TOPUP, 0, ',', '.') ?>" required>
                        </div>
                        <div class="form-text">Min: <?= formatRupiah(MIN_TOPUP) ?> - Max: <?= formatRupiah(MAX_TOPUP) ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw600">Upload Bukti Transfer</label>
                        <input type="file" class="form-control" id="topupProof" name="proof" 
                               accept="image/*" required>
                        <div class="form-text">Format: JPG, PNG. Maks 2MB</div>
                    </div>
                    
                    <button type="button" class="btn btn-primary w-100 py-2" onclick="submitTopup()">
                        <i class="fas fa-paper-plane me-1"></i> Kirim Permintaan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-7">
        <div class="card shadow mb-4 animate-fade-in animate-delay-2">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-history me-2"></i>Riwayat Top Up
                </h6>
                <span class="badge bg-primary badge-custom"><?= count($topups) ?> permintaan</span>
            </div>
            <div class="card-body">
                <?php if (empty($topups)): ?>
                <div class="text-center py-4">
                    <i class="fas fa-wallet fa-3x text-gray-300 mb-3"></i>
                    <p class="text-muted">Belum ada permintaan top up</p>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th>Jumlah</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topups as $t): ?>
                            <tr>
                                <td><strong><?= formatRupiah($t['amount']) ?></strong></td>
                                <td>
                                    <span class="badge badge-custom 
                                        <?= $t['status'] == 'approved' ? 'badge-active' : ($t['status'] == 'rejected' ? 'badge-expired' : 'badge-pending') ?>">
                                        <?= ucfirst($t['status']) ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
