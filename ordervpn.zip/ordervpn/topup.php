<?php
require_once __DIR__ . '/includes/config.php';
$session = requireLogin();
$db = getDB();
$userId = $session['user_id'];

$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Get pending topups
$stmtPending = $db->prepare("SELECT * FROM topup_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmtPending->execute([$userId]);
$topupHistory = $stmtPending->fetchAll();

$message = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (int)$_POST['amount'];
    $method = sanitize($_POST['method'] ?? 'transfer');
    
    if ($amount < MIN_TOPUP) {
        $message = 'Minimal topup ' . formatRupiah(MIN_TOPUP);
        $msgType = 'error';
    } elseif ($amount > MAX_TOPUP) {
        $message = 'Maksimal topup ' . formatRupiah(MAX_TOPUP);
        $msgType = 'error';
    } else {
        $refId = 'TU' . date('YmdHis') . rand(100,999);
        $db->prepare("INSERT INTO topup_requests (user_id, amount, payment_method, status) VALUES (?,?,?,'pending')")
           ->execute([$userId, $amount, $method]);
        
        sendTelegramNotif("🔔 <b>Request Topup</b>\nUser: {$user['username']}\nJumlah: " . formatRupiah($amount) . "\nRef: {$refId}");
        
        $message = "Request topup berhasil dikirim! Silakan transfer ke rekening di bawah dan tunggu konfirmasi admin.";
        $msgType = 'success';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Isi Saldo - <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root { --blue: #2563eb; --bg: #0f172a; --card: #1e293b; --border: #334155; --text: #f1f5f9; --muted: #94a3b8; --radius: 12px; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
.navbar { background: var(--card); border-bottom: 1px solid var(--border); padding: 0 1.5rem; height: 60px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; }
.nav-brand { font-weight: 700; font-size: 1.1rem; }
.nav-links { display: flex; align-items: center; gap: 1rem; }
.nav-links a { color: var(--muted); text-decoration: none; font-size: 0.875rem; font-weight: 500; padding: 0.4rem 0.75rem; border-radius: 8px; }
.nav-links a:hover, .nav-links a.active { color: var(--text); background: #334155; }
.saldo-badge { background: #14532d33; border: 1px solid #16a34a44; padding: 0.4rem 0.9rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; color: #4ade80; }
.bottom-nav { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--card); border-top: 1px solid var(--border); z-index: 100; }
.bottom-nav a { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 0.75rem 0.5rem; color: var(--muted); text-decoration: none; font-size: 0.7rem; gap: 0.25rem; }
.bottom-nav a.active { color: var(--blue); }
.container { max-width: 700px; margin: 0 auto; padding: 1.5rem; }
.page-title { font-size: 1.4rem; font-weight: 700; margin-bottom: 2rem; }
.card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; margin-bottom: 1.5rem; }
.card-head { padding: 1rem 1.25rem; background: #162032; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 0.5rem; font-weight: 700; font-size: 0.95rem; }
.card-body { padding: 1.5rem; }
.bank-info { background: #0f172a; border: 1px solid var(--border); border-radius: 10px; padding: 1.25rem; margin-bottom: 1.5rem; }
.bank-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
.bank-row:last-child { margin-bottom: 0; }
.bank-label { font-size: 0.8rem; color: var(--muted); }
.bank-val { font-size: 1rem; font-weight: 700; }
.copy-inline { background: #1e3a8a44; color: #93c5fd; border: 1px solid #1e3a8a55; border-radius: 6px; padding: 0.25rem 0.6rem; font-size: 0.75rem; cursor: pointer; font-family: inherit; }
.nominal-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; margin-bottom: 1.25rem; }
.nominal-btn { background: #162032; border: 1.5px solid var(--border); border-radius: 10px; padding: 0.75rem; text-align: center; cursor: pointer; font-size: 0.85rem; font-weight: 600; transition: all 0.2s; }
.nominal-btn:hover, .nominal-btn.active { border-color: var(--blue); background: #1e3a8a33; color: #60a5fa; }
.form-group { margin-bottom: 1.25rem; }
label { display: block; font-size: 0.85rem; font-weight: 600; color: var(--muted); margin-bottom: 0.5rem; }
input[type="number"] { width: 100%; padding: 0.75rem 1rem; background: #0f172a; border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.95rem; font-family: inherit; outline: none; }
input:focus { border-color: var(--blue); }
.btn-submit { width: 100%; padding: 0.9rem; background: var(--blue); color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 700; cursor: pointer; font-family: inherit; transition: background 0.2s; }
.btn-submit:hover { background: #1d4ed8; }
.alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.25rem; font-size: 0.875rem; }
.alert-error { background: #7f1d1d22; border: 1px solid #7f1d1d; color: #fca5a5; }
.alert-success { background: #14532d22; border: 1px solid #14532d; color: #86efac; }
.badge { display: inline-flex; padding: 0.25rem 0.65rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
.badge-pending { background: #78350f44; color: #fcd34d; border: 1px solid #78350f44; }
.badge-approved { background: #14532d44; color: #4ade80; border: 1px solid #14532d44; }
.badge-rejected { background: #7f1d1d44; color: #f87171; border: 1px solid #7f1d1d44; }
table { width: 100%; border-collapse: collapse; }
th { padding: 0.6rem 0.75rem; font-size: 0.75rem; font-weight: 600; color: var(--muted); background: #162032; border-bottom: 1px solid var(--border); text-align: left; }
td { padding: 0.75rem; font-size: 0.85rem; border-bottom: 1px solid #1e293b; }
tr:last-child td { border-bottom: none; }
.empty { text-align: center; padding: 2rem; color: var(--muted); }
@media(max-width:768px) { .navbar .nav-links{display:none;} .bottom-nav{display:flex;} .container{padding:1rem;padding-bottom:5rem;} .nominal-grid{grid-template-columns:repeat(2,1fr);} }
</style>
</head>
<body>
<nav class="navbar">
  <div class="nav-brand">🛡️ <?= APP_NAME ?></div>
  <div class="nav-links">
    <a href="/dashboard.php">📊 Dashboard</a>
    <a href="/servers.php">🖥️ Server</a>
    <a href="/topup.php" class="active">💰 Topup</a>
  </div>
  <div style="display:flex;align-items:center;gap:1rem;">
    <span class="saldo-badge">💰 <?= formatRupiah($user['saldo']) ?></span>
    <a href="/logout.php" style="color:var(--muted);text-decoration:none;font-size:0.875rem;">Logout</a>
  </div>
</nav>
<nav class="bottom-nav">
  <a href="/dashboard.php"><span>📊</span>Dashboard</a>
  <a href="/servers.php"><span>🖥️</span>Server</a>
  <a href="/topup.php" class="active"><span>💰</span>Topup</a>
  <a href="/logout.php"><span>🚪</span>Logout</a>
</nav>

<div class="container">
  <div class="page-title">💰 Isi Saldo</div>

  <!-- Bank Info -->
  <div class="card">
    <div class="card-head">🏦 Rekening Tujuan Transfer</div>
    <div class="card-body">
      <div class="bank-info">
        <div class="bank-row">
          <div><div class="bank-label">Bank</div><div class="bank-val"><?= BANK_NAME ?></div></div>
        </div>
        <div class="bank-row">
          <div><div class="bank-label">No. Rekening</div><div class="bank-val" id="noRek"><?= BANK_ACCOUNT ?></div></div>
          <button class="copy-inline" onclick="copyText('<?= BANK_ACCOUNT ?>')">📋 Copy</button>
        </div>
        <div class="bank-row">
          <div><div class="bank-label">Atas Nama</div><div class="bank-val"><?= BANK_HOLDER ?></div></div>
        </div>
      </div>
      <div style="font-size:0.8rem;color:var(--muted);line-height:1.6;">
        ⚠️ Setelah transfer, konfirmasi ke admin dengan mengirim bukti transfer. Saldo akan diproses dalam 1×24 jam.
      </div>
    </div>
  </div>

  <!-- Topup Form -->
  <div class="card">
    <div class="card-head">📤 Request Topup</div>
    <div class="card-body">
      <?php if ($message): ?>
      <div class="alert alert-<?= $msgType ?>"><?= $message ?></div>
      <?php endif; ?>
      
      <form method="POST">
        <div class="form-group">
          <label>Pilih Nominal</label>
          <div class="nominal-grid">
            <?php foreach ([10000,20000,50000,100000,200000,500000] as $nom): ?>
            <div class="nominal-btn" onclick="setNominal(<?= $nom ?>, this)">
              Rp <?= number_format($nom,0,'.','.') ?>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        
        <div class="form-group">
          <label>Atau Masukkan Nominal (Min. <?= formatRupiah(MIN_TOPUP) ?>)</label>
          <input type="number" name="amount" id="amountInput" placeholder="<?= MIN_TOPUP ?>" min="<?= MIN_TOPUP ?>" max="<?= MAX_TOPUP ?>">
        </div>
        
        <input type="hidden" name="method" value="transfer">
        
        <button type="submit" class="btn-submit">📤 Request Topup</button>
      </form>
    </div>
  </div>

  <!-- Topup History -->
  <div class="card">
    <div class="card-head">📋 Riwayat Request Topup</div>
    <?php if (empty($topupHistory)): ?>
    <div class="empty">Belum ada request topup</div>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Tanggal</th>
          <th>Jumlah</th>
          <th>Status</th>
          <th>Catatan</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($topupHistory as $tp): ?>
        <tr>
          <td style="font-size:0.8rem;color:var(--muted);"><?= date('d/m/Y H:i', strtotime($tp['created_at'])) ?></td>
          <td style="font-weight:600;color:#60a5fa;"><?= formatRupiah($tp['amount']) ?></td>
          <td><span class="badge badge-<?= $tp['status'] ?>"><?= $tp['status'] ?></span></td>
          <td style="font-size:0.8rem;color:var(--muted);"><?= htmlspecialchars($tp['admin_note'] ?? '-') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function setNominal(amount, el) {
  document.querySelectorAll('.nominal-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('amountInput').value = amount;
}
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target; const orig = btn.textContent;
    btn.textContent = '✓ Copied!'; setTimeout(() => btn.textContent = orig, 1500);
  });
}
</script>
</body>
</html>
