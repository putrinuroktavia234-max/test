            </div>
            <!-- End Page Content -->

        </div>
        <!-- End Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white mt-auto">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span class="text-muted">&copy; <?= date('Y') ?> <a href="https://t.me/YouzinCrabz" class="text-primary text-decoration-none"><?= APP_NAME ?></a>. All rights reserved.</span>
                </div>
            </div>
        </footer>

    </div>
    <!-- End Content Wrapper -->

</div>
<!-- End Page Wrapper -->

<!-- Scroll to Top -->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- SB Admin 2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/js/sb-admin-2.min.js"></script>
<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<!-- Custom JS -->
<script src="assets/js/script.js"></script>

<!-- Order Modal -->
<div class="modal fade modal-custom" id="orderModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-cart-plus me-2"></i>Order VPN Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="orderForm">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <div class="mb-3">
                        <label class="form-label fw600">Tipe VPN</label>
                        <select class="form-select" name="type" required>
                            <option value="ssh">SSH</option>
                            <option value="vmess">VMess</option>
                            <option value="vless">VLess</option>
                            <option value="trojan">Trojan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw600">Server</label>
                        <select class="form-select" name="server_id" id="serverSelect" required>
                            <option value="">Loading server...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw600">Username</label>
                        <input type="text" class="form-control" name="username" required minlength="3" maxlength="20" placeholder="Masukkan username">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw600">Durasi (hari)</label>
                        <select class="form-select" name="days" id="daysSelect" required>
                            <option value="30">30 Hari</option>
                            <option value="60">60 Hari</option>
                            <option value="90">90 Hari</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw600">Total Harga</label>
                        <div class="p-3 bg-light rounded text-center">
                            <h4 class="mb-0 text-primary fw-bold" id="priceDisplay">Rp 0</h4>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button class="btn btn-primary" id="orderSubmitBtn" onclick="submitOrder()">
                    <i class="fas fa-shopping-cart me-1"></i> Pesan Sekarang
                </button>
            </div>
        </div>
    </div>
</div>

</body>
</html>
