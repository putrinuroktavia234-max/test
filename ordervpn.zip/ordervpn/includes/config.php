<?php
// ============================================================
// OrderVPN - Configuration File
// Edit sesuai settings server kamu
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // ganti dengan user MySQL kamu
define('DB_PASS', 'password');      // ganti dengan password MySQL kamu
define('DB_NAME', 'ordervpn_db');
define('DB_PORT', 3306);

// ============================================================
// App Settings
// ============================================================
define('APP_NAME', 'OrderVPN');
define('APP_URL', 'http://localhost');  // ganti dengan domain kamu
define('APP_VERSION', '1.0.0');

// ============================================================
// Session Settings
// ============================================================
define('SESSION_LIFETIME', 86400); // 24 jam

// ============================================================
// Payment / Topup Settings
// ============================================================
define('MIN_TOPUP', 5000);      // Minimum topup (Rp)
define('MAX_TOPUP', 1000000);   // Maximum topup (Rp)

// Rekening tujuan topup (tampil ke user)
define('BANK_NAME', 'BCA');
define('BANK_ACCOUNT', '1234567890');
define('BANK_HOLDER', 'Admin OrderVPN');

// ============================================================
// Tunnel Script Settings
// Sesuaikan dengan lokasi script tunnel.sh kamu
// ============================================================
define('TUNNEL_SCRIPT', '/root/tunnel.sh');
define('SSH_KEY_PATH', '/root/.ssh/id_rsa');

// ============================================================
// Notification (opsional - Telegram)
// ============================================================
define('TG_BOT_TOKEN', '');   // isi jika mau notif Telegram
define('TG_CHAT_ID', '');     // Chat ID admin

// ============================================================
// Database Connection
// ============================================================
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ============================================================
// Helper Functions
// ============================================================
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function sendTelegramNotif($message) {
    if (empty(TG_BOT_TOKEN) || empty(TG_CHAT_ID)) return;
    $url = "https://api.telegram.org/bot" . TG_BOT_TOKEN . "/sendMessage";
    $data = ['chat_id' => TG_CHAT_ID, 'text' => $message, 'parse_mode' => 'HTML'];
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5,
    ]);
    curl_exec($ch);
    curl_close($ch);
}

// Auth check helper
function requireLogin() {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
    return $_SESSION;
}

function requireAdmin() {
    $session = requireLogin();
    if ($session['role'] !== 'admin') {
        header('Location: /dashboard.php');
        exit;
    }
    return $session;
}
