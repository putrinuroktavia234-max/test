<?php
/**
 * OrderVPN - VPN Account Manager
 * Handles creation, deletion, and management of VPN accounts
 */

class VPNManager {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function createAccount($user_id, $type, $server_id, $username, $days) {
        // Validate
        if (!in_array($type, ['ssh', 'vmess', 'vless', 'trojan'])) {
            return ['success' => false, 'message' => 'Tipe VPN tidak valid'];
        }
        
        $server = $this->getServer($server_id);
        if (!$server) {
            return ['success' => false, 'message' => 'Server tidak ditemukan'];
        }
        
        // Calculate price
        $months = ceil($days / 30);
        $total_price = $server['monthly_price'] * $months;
        
        // Check balance
        $user = $this->getUser($user_id);
        if ($user['balance'] < $total_price) {
            return ['success' => false, 'message' => 'Saldo tidak mencukupi. Butuh ' . formatRupiah($total_price)];
        }
        
        // Execute tunnel.sh to create account
        $uuid = generateUUID();
        $expired_at = date('Y-m-d H:i:s', strtotime("+{$days} days"));
        
        $cmd = "bash " . escapeshellarg(TUNNEL_SCRIPT) . " create " . escapeshellarg($type) . " " . escapeshellarg($username) . " " . escapeshellarg($days) . " 999 1";
        $output = shell_exec($cmd . " 2>&1");
        
        // Generate config link
        $domain = $server['host'];
        $config_link = "";
        switch ($type) {
            case 'vmess':
                $config_link = "vmess://" . base64_encode(json_encode([
                    'v' => '2', 'ps' => $username, 'add' => 'bug.com',
                    'port' => '443', 'id' => $uuid, 'aid' => '0',
                    'net' => 'ws', 'path' => "/{$type}", 'type' => 'none',
                    'host' => $domain, 'tls' => 'tls'
                ]));
                break;
            case 'vless':
                $config_link = "vless://{$uuid}@bug.com:443?path=%2F{$type}&security=tls&encryption=none&host={$domain}&type=ws&sni={$domain}#{$username}-TLS";
                break;
            case 'trojan':
                $config_link = "trojan://{$uuid}@bug.com:443?path=%2F{$type}&security=tls&host={$domain}&type=ws&sni={$domain}#{$username}-TLS";
                break;
            case 'ssh':
                $config_link = "ssh://{$username}@{$domain}:22";
                break;
        }
        
        // Save to database
        $stmt = $this->db->prepare("INSERT INTO vpn_accounts (user_id, server_id, type, username, uuid, config_link, created_at, expired_at, price, status) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?, 'active')");
        $stmt->execute([$user_id, $server_id, $type, $username, $uuid, $config_link, $expired_at, $total_price]);
        $account_id = $this->db->lastInsertId();
        
        // Deduct balance
        $stmt = $this->db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$total_price, $user_id]);
        
        // Record transaction
        $stmt = $this->db->prepare("INSERT INTO transactions (user_id, type, amount, status, description, created_at) VALUES (?, 'order', ?, 'completed', ?, NOW())");
        $stmt->execute([$user_id, $total_price, "Order {$type} - {$username} ({$days} hari)"]);
        
        // Notify Telegram
        $msg = "🆕 Akun Baru\nUser: {$user['username']}\nTipe: " . strtoupper($type) . "\nUsername: {$username}\nHarga: " . formatRupiah($total_price) . "\nExp: {$expired_at}";
        sendTelegramNotif($msg);
        
        return ['success' => true, 'message' => 'Akun ' . strtoupper($type) . ' berhasil dibuat!', 'account_id' => $account_id];
    }
    
    public function deleteAccount($account_id) {
        $stmt = $this->db->prepare("SELECT * FROM vpn_accounts WHERE id = ?");
        $stmt->execute([$account_id]);
        $account = $stmt->fetch();
        
        if (!$account) {
            return ['success' => false, 'message' => 'Akun tidak ditemukan'];
        }
        
        // Execute tunnel.sh to delete
        $cmd = "bash " . escapeshellarg(TUNNEL_SCRIPT) . " delete " . escapeshellarg($account['type']) . " " . escapeshellarg($account['username']);
        shell_exec($cmd . " 2>&1");
        
        // Update database
        $stmt = $this->db->prepare("UPDATE vpn_accounts SET status = 'deleted' WHERE id = ?");
        $stmt->execute([$account_id]);
        
        return ['success' => true, 'message' => 'Akun berhasil dihapus'];
    }
    
    public function getServer($server_id) {
        $stmt = $this->db->prepare("SELECT * FROM servers WHERE id = ?");
        $stmt->execute([$server_id]);
        return $stmt->fetch();
    }
    
    public function getUser($user_id) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        return $stmt->fetch();
    }
    
    public function getAllServers() {
        $stmt = $this->db->query("SELECT * FROM servers WHERE status = 'active' ORDER BY name ASC");
        return $stmt->fetchAll();
    }
}
