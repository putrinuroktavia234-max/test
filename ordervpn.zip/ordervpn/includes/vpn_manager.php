<?php
// ============================================================
// OrderVPN - VPN Account Manager
// Wrapper untuk tunnel.sh / xray management script
// ============================================================

require_once __DIR__ . '/config.php';

class VPNManager {

    /**
     * Buat akun VPN baru via SSH ke server
     * Fungsi ini akan SSH ke server VPS dan jalankan perintah xray
     */
    public static function createAccount($server, $type, $username, $days, $quota = 0) {
        $host = $server['host'];
        $port = $server['port'] ?? 22;
        $sshUser = $server['ssh_user'] ?? 'root';
        $sshKey = SSH_KEY_PATH;

        // Buat UUID untuk vmess/vless/trojan
        $uuid = generateUUID();
        $expDate = date('Y-m-d', strtotime("+{$days} days"));
        $expStr = date('d-m-Y', strtotime("+{$days} days"));

        // Command sesuai tipe VPN (sesuaikan dengan format script tunnel.sh kamu)
        switch (strtolower($type)) {
            case 'vmess':
                // Contoh command untuk tunnel.sh style
                $cmd = "bash " . TUNNEL_SCRIPT . " add-vmess {$username} {$days} {$quota}";
                break;
            case 'vless':
                $cmd = "bash " . TUNNEL_SCRIPT . " add-vless {$username} {$days} {$quota}";
                break;
            case 'trojan':
                $cmd = "bash " . TUNNEL_SCRIPT . " add-trojan {$username} {$days} {$quota}";
                break;
            case 'ssh':
                $cmd = "bash " . TUNNEL_SCRIPT . " add-ssh {$username} {$days} {$quota}";
                break;
            default:
                return ['success' => false, 'message' => 'Tipe VPN tidak valid'];
        }

        // SSH ke server dan jalankan command
        $sshCmd = "ssh -i {$sshKey} -o StrictHostKeyChecking=no -o ConnectTimeout=15 -p {$port} {$sshUser}@{$host} '{$cmd}' 2>&1";
        
        exec($sshCmd, $output, $returnCode);
        $outputStr = implode("\n", $output);

        if ($returnCode !== 0) {
            return [
                'success' => false,
                'message' => 'Gagal membuat akun: ' . $outputStr
            ];
        }

        // Parse link config dari output script
        $linkConfig = self::parseLinkFromOutput($outputStr, $type);

        return [
            'success' => true,
            'uuid' => $uuid,
            'username' => $username,
            'link_config' => $linkConfig,
            'expired' => $expDate,
            'raw_output' => $outputStr,
        ];
    }

    /**
     * Hapus akun VPN dari server
     */
    public static function deleteAccount($server, $type, $username) {
        $host = $server['host'];
        $port = $server['port'] ?? 22;
        $sshUser = $server['ssh_user'] ?? 'root';

        switch (strtolower($type)) {
            case 'vmess': $cmd = "bash " . TUNNEL_SCRIPT . " del-vmess {$username}"; break;
            case 'vless': $cmd = "bash " . TUNNEL_SCRIPT . " del-vless {$username}"; break;
            case 'trojan': $cmd = "bash " . TUNNEL_SCRIPT . " del-trojan {$username}"; break;
            case 'ssh': $cmd = "bash " . TUNNEL_SCRIPT . " del-ssh {$username}"; break;
            default: return ['success' => false, 'message' => 'Tipe VPN tidak valid'];
        }

        $sshCmd = "ssh -i " . SSH_KEY_PATH . " -o StrictHostKeyChecking=no -o ConnectTimeout=15 -p {$port} {$sshUser}@{$host} '{$cmd}' 2>&1";
        exec($sshCmd, $output, $returnCode);

        return ['success' => $returnCode === 0, 'message' => implode("\n", $output)];
    }

    /**
     * Cek status server via SSH ping
     */
    public static function checkServerStatus($server) {
        $host = $server['host'];
        $port = $server['port'] ?? 22;
        
        exec("nc -z -w3 {$host} {$port} 2>&1", $output, $code);
        return $code === 0 ? 'ready' : 'offline';
    }

    /**
     * Cek expired accounts dan suspend otomatis
     */
    public static function processExpiredAccounts() {
        $db = getDB();
        $stmt = $db->prepare("SELECT va.*, s.host, s.port, s.ssh_user FROM vpn_accounts va JOIN servers s ON va.server_id = s.id WHERE va.masa_aktif < CURDATE() AND va.status = 'active'");
        $stmt->execute();
        $expired = $stmt->fetchAll();

        foreach ($expired as $acc) {
            self::deleteAccount($acc, $acc['tipe'], $acc['username']);
            $db->prepare("UPDATE vpn_accounts SET status = 'expired' WHERE id = ?")->execute([$acc['id']]);
        }

        return count($expired);
    }

    /**
     * Parse link config dari output script
     * Sesuaikan regex dengan format output tunnel.sh kamu
     */
    private static function parseLinkFromOutput($output, $type) {
        $prefix = strtolower($type) . '://';
        if (preg_match('/' . preg_quote($prefix, '/') . '[^\s]+/i', $output, $matches)) {
            return $matches[0];
        }
        // Fallback: cari baris yang ada link
        foreach (explode("\n", $output) as $line) {
            if (strpos($line, '://') !== false) return trim($line);
        }
        return null;
    }

    /**
     * Generate link config manual (jika tidak bisa SSH)
     * Untuk demo / testing tanpa VPS nyata
     */
    public static function generateDemoConfig($server, $type, $username, $uuid) {
        $host = $server['host'];
        
        switch ($type) {
            case 'vmess':
                $config = base64_encode(json_encode([
                    'v' => '2', 'ps' => $username, 'add' => $host,
                    'port' => $server['xray_port_vmess'] ?? 443,
                    'id' => $uuid, 'aid' => '0', 'net' => 'ws',
                    'type' => 'none', 'host' => $host, 'path' => '/vmess',
                    'tls' => 'tls'
                ]));
                return 'vmess://' . $config;
                
            case 'vless':
                return "vless://{$uuid}@{$host}:{$server['xray_port_vless']}?encryption=none&security=tls&type=ws&path=%2Fvless&host={$host}#{$username}";
                
            case 'trojan':
                return "trojan://{$uuid}@{$host}:{$server['xray_port_trojan']}?security=tls&type=ws&path=%2Ftrojan&host={$host}#{$username}";
                
            default:
                return null;
        }
    }
}
