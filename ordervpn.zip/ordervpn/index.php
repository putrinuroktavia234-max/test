<?php
require_once __DIR__ . '/includes/config.php';
session_start();

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: /dashboard.php');
    exit;
}

$error = '';
$success = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'login') {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Username dan password wajib diisi!';
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['saldo'] = $user['saldo'];
                
                // Update IP
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
                $db->prepare("UPDATE users SET ip_address = ? WHERE id = ?")->execute([$ip, $user['id']]);
                
                header('Location: /dashboard.php');
                exit;
            } else {
                $error = 'Username atau password salah!';
            }
        }
    }
    
    if ($action === 'register') {
        $username = sanitize($_POST['reg_username'] ?? '');
        $email = sanitize($_POST['reg_email'] ?? '');
        $password = $_POST['reg_password'] ?? '';
        $confirm = $_POST['reg_confirm'] ?? '';
        
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Semua field wajib diisi!';
        } elseif ($password !== $confirm) {
            $error = 'Password tidak cocok!';
        } elseif (strlen($password) < 6) {
            $error = 'Password minimal 6 karakter!';
        } else {
            $db = getDB();
            $check = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $check->execute([$username, $email]);
            if ($check->fetch()) {
                $error = 'Username atau email sudah digunakan!';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $db->prepare("INSERT INTO users (username, email, password) VALUES (?,?,?)")
                   ->execute([$username, $email, $hash]);
                $success = 'Akun berhasil dibuat! Silakan login.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= APP_NAME ?> - Login</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --blue: #2563eb; --blue-dark: #1d4ed8; --blue-light: #dbeafe;
  --green: #16a34a; --green-light: #dcfce7;
  --red: #dc2626; --red-light: #fee2e2;
  --gray-50: #f8fafc; --gray-100: #f1f5f9; --gray-200: #e2e8f0;
  --gray-400: #94a3b8; --gray-600: #475569; --gray-800: #1e293b; --gray-900: #0f172a;
  --white: #ffffff;
  --shadow: 0 4px 24px rgba(0,0,0,0.08);
  --radius: 12px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Plus Jakarta Sans', sans-serif; background: #0f172a; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
body::before {
  content: ''; position: fixed; inset: 0;
  background: radial-gradient(ellipse at top left, #1e3a8a22 0%, transparent 50%),
              radial-gradient(ellipse at bottom right, #16338722 0%, transparent 50%);
  pointer-events: none;
}
.login-wrap { width: 100%; max-width: 440px; position: relative; z-index: 1; }
.logo { text-align: center; margin-bottom: 2rem; }
.logo-icon { font-size: 2.5rem; }
.logo h1 { color: #fff; font-size: 1.75rem; font-weight: 700; margin-top: 0.5rem; }
.logo p { color: #94a3b8; font-size: 0.9rem; margin-top: 0.25rem; }
.card { background: #1e293b; border: 1px solid #334155; border-radius: 16px; padding: 2rem; }
.tabs { display: flex; background: #0f172a; border-radius: 8px; padding: 4px; margin-bottom: 1.5rem; gap: 4px; }
.tab-btn { flex: 1; padding: 0.6rem; border: none; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 500; font-family: inherit; transition: all 0.2s; }
.tab-btn.active { background: var(--blue); color: white; }
.tab-btn:not(.active) { background: transparent; color: #94a3b8; }
.tab-content { display: none; }
.tab-content.active { display: block; }
.form-group { margin-bottom: 1rem; }
label { display: block; font-size: 0.85rem; font-weight: 500; color: #94a3b8; margin-bottom: 0.4rem; }
input[type="text"], input[type="email"], input[type="password"] {
  width: 100%; padding: 0.75rem 1rem; background: #0f172a; border: 1px solid #334155;
  border-radius: 8px; color: #fff; font-size: 0.95rem; font-family: inherit; outline: none; transition: border 0.2s;
}
input:focus { border-color: var(--blue); }
input::placeholder { color: #475569; }
.btn { width: 100%; padding: 0.85rem; border: none; border-radius: 8px; font-size: 0.95rem; font-weight: 600; cursor: pointer; font-family: inherit; transition: all 0.2s; margin-top: 0.5rem; }
.btn-primary { background: var(--blue); color: white; }
.btn-primary:hover { background: var(--blue-dark); }
.alert { padding: 0.75rem 1rem; border-radius: 8px; font-size: 0.875rem; margin-bottom: 1rem; }
.alert-error { background: #7f1d1d22; border: 1px solid #7f1d1d; color: #fca5a5; }
.alert-success { background: #14532d22; border: 1px solid #14532d; color: #86efac; }
.demo-note { text-align: center; margin-top: 1.5rem; padding: 0.75rem; background: #172033; border-radius: 8px; font-size: 0.8rem; color: #64748b; }
.demo-note span { color: #60a5fa; }
</style>
</head>
<body>
<div class="login-wrap">
  <div class="logo">
    <div class="logo-icon">🛡️</div>
    <h1><?= APP_NAME ?></h1>
    <p>Premium VPN Service Indonesia</p>
  </div>
  
  <div class="card">
    <div class="tabs">
      <button class="tab-btn active" onclick="switchTab('login')">Login</button>
      <button class="tab-btn" onclick="switchTab('register')">Daftar</button>
    </div>
    
    <?php if ($error): ?>
    <div class="alert alert-error"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    
    <!-- Login Form -->
    <div class="tab-content active" id="tab-login">
      <form method="POST">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label>Username / Email</label>
          <input type="text" name="username" placeholder="Masukkan username atau email" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Masukkan password" required>
        </div>
        <button type="submit" class="btn btn-primary">🔐 Login</button>
      </form>
    </div>
    
    <!-- Register Form -->
    <div class="tab-content" id="tab-register">
      <form method="POST">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="reg_username" placeholder="Buat username" required>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="reg_email" placeholder="Email kamu" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="reg_password" placeholder="Min. 6 karakter" required>
        </div>
        <div class="form-group">
          <label>Konfirmasi Password</label>
          <input type="password" name="reg_confirm" placeholder="Ulangi password" required>
        </div>
        <button type="submit" class="btn btn-primary">✨ Buat Akun</button>
      </form>
    </div>
  </div>
  
  <div class="demo-note">
    Demo admin: <span>admin / password</span>
  </div>
</div>

<script>
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b,i) => b.classList.toggle('active', (i===0&&tab==='login')||(i===1&&tab==='register')));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
}
<?php if ($success): ?>switchTab('login');<?php endif; ?>
</script>
</body>
</html>
