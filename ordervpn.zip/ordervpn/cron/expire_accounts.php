#!/usr/bin/env php
<?php
// cron/expire_accounts.php
// Jalankan setiap hari via crontab:
// 0 1 * * * php /var/www/html/ordervpn/cron/expire_accounts.php

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/vpn_manager.php';

$count = VPNManager::processExpiredAccounts();
echo "[" . date('Y-m-d H:i:s') . "] Processed {$count} expired accounts.\n";
