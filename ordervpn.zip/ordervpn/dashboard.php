<?php
require_once __DIR__ . '/includes/config.php';
$session = requireLogin();

$db = getDB();
$userId = $session['user_id'];

// Get fresh user data
$user = $db->prepare("SELECT * FROM users WHERE id = ?")->execute([$userId]) ? 
        $db->prepare("SELECT * FROM users WHERE id = ?")->execute([$userId]) : null;
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();
$_SESSION['saldo'] = $user['saldo'];

// Get active VPN accounts
$stmtVPN = $db->prepare("SELECT va.*, s.nama_server, s.code_server, s.lokasi, s.host FROM vpn_accounts va JOIN servers s ON va.server_id = s.id WHERE va.user_id = ? ORDER BY va.created_at DESC LIMIT 20");
$stmtVPN->execute([$userId]);
$vpnAccounts = $stmtVPN->fetchAll();

// Get transactions
$stmtTx = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmtTx->execute([$userId]);
$transactions = $stmtTx->fetchAll();

// Stats
$activeCount = count(array_filter($vpnAccounts, fn($v) => $v['status'] === 'active'));
$expiredCount = count(array_filter($vpnAccounts, fn($v) => $v['status'] === 'expired'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --blue: #2563eb; --blue-dark: #1d4ed8; --blue-light: #1e3a8a;
  --green: #16a34a; --yellow: #ca8a04; --red: #dc2626;
  --bg: #0f172a; --card: #1e293b; --card2: #162032;
  --border: #334155; --text: #f1f5f9; --muted: #94a3b8;
  --radius: 12px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }

/* Navbar */
.navbar { background: var(--card); border-bottom: 1px solid var(--border); padding: 0 1.5rem; height: 60px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; }
.nav-brand { font-weight: 700; font-size: 1.1rem; color: var(--text); display: flex; align-items: center; gap: 0.5rem; }
.nav-right { display: flex; align-items: center; gap: 1rem; }
.saldo-badge { background: #14532d33; border: 1px solid #16a34a44; padding: 0.4rem 0.9rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; color: #4ade80; }
.nav-user { font-size: 0.85rem; color: var(--muted); }
.btn-logout { background: #7f1d1d33; border: 1px solid #7f1d1d55; color: #fca5a5; padding: 0.4rem 0.9rem; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 500; cursor: pointer; }
.btn-logout:hover { background: #7f1d1d55; }

/* Bottom nav mobile */
.bottom-nav { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--card); border-top: 1px solid var(--border); z-index: 100; }
.bottom-nav a { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 0.75rem 0.5rem; color: var(--muted); text-decoration: none; font-size: 0.7rem; gap: 0.25rem; transition: color 0.2s; }
.bottom-nav a.active { color: var(--blue); }
.bottom-nav a span { font-size: 1.1rem; }

/* Layout */
.container { max-width: 1100px; margin: 0 auto; padding: 1.5rem; }
.section-title { font-size: 0.75rem; font-weight: 600; color: var(--muted); letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 1rem; }

/* Stats grid */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.stat-card { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.25rem; }
.stat-label { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.5rem; }
.stat-value { font-size: 1.6rem; font-weight: 700; }
.stat-value.green { color: #4ade80; }
.stat-value.blue { color: #60a5fa; }
.stat-value.yellow { color: #fbbf24; }
.stat-value.red { color: #f87171; }

/* Table */
.table-wrap { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; margin-bottom: 2rem; }
.table-header { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
.table-header h3 { font-size: 0.95rem; font-weight: 600; }
table { width: 100%; border-collapse: collapse; }
th { padding: 0.75rem 1rem; font-size: 0.75rem; font-weight: 600; color: var(--muted); text-align: left; background: #162032; border-bottom: 1px solid var(--border); }
td { padding: 0.9rem 1rem; font-size: 0.875rem; border-bottom: 1px solid #1e293b; vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: #1e2d45; }

/* Badges */
.badge { display: inline-flex; align-items: center; gap: 4px; padding: 0.25rem 0.65rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
.badge-active { background: #14532d44; color: #4ade80; border: 1px solid #16a34a44; }
.badge-expired { background: #7f1d1d44; color: #f87171; border: 1px solid #7f1d1d44; }
.badge-vmess { background: #1e3a8a44; color: #93c5fd; }
.badge-vless { background: #3730a344; color: #a5b4fc; }
.badge-trojan { background: #78350f44; color: #fcd34d; }
.badge-ssh { background: #16537a44; color: #67e8f9; }

/* Buttons */
.btn { padding: 0.55rem 1.1rem; border-radius: 8px; font-size: 0.875rem; font-weight: 600; cursor: pointer; font-family: inherit; border: none; transition: all 0.2s; text-decoration: none; display: inline-flex; align-items: center; gap: 0.4rem; }
.btn-primary { background: var(--blue); color: white; }
.btn-primary:hover { background: var(--blue-dark); }
.btn-sm { padding: 0.35rem 0.7rem; font-size: 0.8rem; }
.btn-danger { background: #7f1d1d33; color: #fca5a5; border: 1px solid #7f1d1d55; }
.btn-info { background: #1e3a8a44; color: #93c5fd; border: 1px solid #1e3a8a55; }
.btn-success { background: #14532d44; color: #4ade80; border: 1px solid #14532d55; }

/* Config modal */
.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center; padding: 1rem; }
.modal-overlay.show { display: flex; }
.modal { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.75rem; width: 100%; max-width: 560px; max-height: 90vh; overflow-y: auto; }
.modal h3 { font-size: 1.1rem; font-weight: 700; margin-bottom: 1.25rem; }
.config-row { margin-bottom: 1rem; }
.config-label { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.3rem; }
.config-val { background: #0f172a; border: 1px solid var(--border); border-radius: 8px; padding: 0.75rem 1rem; font-family: monospace; font-size: 0.85rem; word-break: break-all; position: relative; }
.copy-btn { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: var(--blue); color: white; border: none; border-radius: 6px; padding: 0.25rem 0.6rem; font-size: 0.75rem; cursor: pointer; }
.modal-close { float: right; background: none; border: none; color: var(--muted); font-size: 1.5rem; cursor: pointer; line-height: 1; }

/* Empty state */
.empty-state { text-align: center; padding: 3rem 1rem; color: var(--muted); }
.empty-state .icon { font-size: 3rem; margin-bottom: 1rem; display: block; }

@media (max-width: 768px) {
  .navbar .nav-user, .navbar .btn-logout { display: none; }
  .bottom-nav { display: flex; }
  .container { padding: 1rem; padding-bottom: 5rem; }
  table { font-size: 0.8rem; }
  th, td { padding: 0.6rem 0.75rem; }
  .hide-mobile { display: none; }
}
</style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar">
  <div class="nav-brand">🛡️ <?= APP_NAME ?></div>
  <div class="nav-right">
    <span class="saldo-badge">💰 <?= formatRupiah($user['saldo']) ?></span>
    <span class="nav-user">👤 <?= htmlspecialchars($user['username']) ?></span>
    <?php if ($user['role'] === 'admin'): ?>
    <a href="/admin.php" class="btn-logout" style="background:#1e3a8a33;border-color:#2563eb44;color:#60a5fa;">⚙️ Admin</a>
    <?php endif; ?>
    <a href="/logout.php" class="btn-logout">Logout</a>
  </div>
</nav>

<!-- Bottom Nav Mobile -->
<nav class="bottom-nav">
  <a href="/dashboard.php" class="active"><span>📊</span>Dashboard</a>
  <a href="/servers.php"><span>🖥️</span>Server</a>
  <a href="/topup.php"><span>💰</span>Topup</a>
  <a href="/logout.php"><span>🚪</span>Logout</a>
</nav>

<div class="container">
  <!-- Stats -->
  <div class="section-title">Overview Akun</div>
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-label">Saldo Kamu</div>
      <div class="stat-value green"><?= formatRupiah($user['saldo']) ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">VPN Aktif</div>
      <div class="stat-value blue"><?= $activeCount ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">VPN Expired</div>
      <div class="stat-value red"><?= $expiredCount ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Order</div>
      <div class="stat-value yellow"><?= count($vpnAccounts) ?></div>
    </div>
  </div>
  
  <!-- Quick Actions -->
  <div style="display:flex;gap:0.75rem;margin-bottom:2rem;flex-wrap:wrap;">
    <a href="/servers.php" class="btn btn-primary">🖥️ Pilih Server</a>
    <a href="/topup.php" class="btn" style="background:#14532d44;color:#4ade80;border:1px solid #14532d55;">💰 Isi Saldo</a>
  </div>

  <!-- VPN Accounts Table -->
  <div class="table-wrap">
    <div class="table-header">
      <h3>📋 Akun VPN Saya</h3>
    </div>
    <?php if (empty($vpnAccounts)): ?>
    <div class="empty-state">
      <span class="icon">🔒</span>
      <p>Belum ada akun VPN</p>
      <a href="/servers.php" class="btn btn-primary" style="margin-top:1rem;">Order Sekarang</a>
    </div>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Server</th>
          <th>Tipe</th>
          <th>Username</th>
          <th class="hide-mobile">Expired</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($vpnAccounts as $acc): ?>
        <tr>
          <td>
            <div style="font-weight:600;font-size:0.8rem;"><?= htmlspecialchars($acc['nama_server']) ?></div>
            <div style="font-size:0.75rem;color:var(--muted);"><?= htmlspecialchars($acc['lokasi']) ?></div>
          </td>
          <td><span class="badge badge-<?= $acc['tipe'] ?>"><?= strtoupper($acc['tipe']) ?></span></td>
          <td style="font-family:monospace;font-size:0.85rem;"><?= htmlspecialchars($acc['username']) ?></td>
          <td class="hide-mobile" style="font-size:0.8rem;">
            <?= date('d/m/Y', strtotime($acc['masa_aktif'])) ?>
            <?php 
              $daysLeft = ceil((strtotime($acc['masa_aktif']) - time()) / 86400);
              if ($daysLeft <= 3 && $acc['status'] === 'active'):
            ?>
            <div style="color:#fbbf24;font-size:0.75rem;">⚠️ <?= $daysLeft ?> hari lagi</div>
            <?php endif; ?>
          </td>
          <td>
            <span class="badge badge-<?= $acc['status'] ?>">
              <?= $acc['status'] === 'active' ? '✅ Aktif' : '❌ Expired' ?>
            </span>
          </td>
          <td>
            <?php if ($acc['link_config']): ?>
            <button class="btn btn-info btn-sm" onclick="showConfig(<?= htmlspecialchars(json_encode($acc)) ?>)">📋 Config</button>
            <?php endif; ?>
            <button class="btn btn-danger btn-sm" onclick="deleteAccount(<?= $acc['id'] ?>, '<?= htmlspecialchars($acc['username']) ?>')">🗑️</button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- Transactions -->
  <div class="table-wrap">
    <div class="table-header">
      <h3>💸 Riwayat Transaksi</h3>
    </div>
    <?php if (empty($transactions)): ?>
    <div class="empty-state" style="padding:2rem;">
      <p>Belum ada transaksi</p>
    </div>
    <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Tanggal</th>
          <th>Keterangan</th>
          <th>Jumlah</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($transactions as $tx): ?>
        <tr>
          <td style="font-size:0.8rem;color:var(--muted);"><?= date('d/m/Y H:i', strtotime($tx['created_at'])) ?></td>
          <td><?= htmlspecialchars($tx['keterangan']) ?></td>
          <td style="font-weight:600;color:<?= $tx['type']==='topup'?'#4ade80':'#f87171' ?>;">
            <?= $tx['type']==='topup'?'+':'-' ?><?= formatRupiah($tx['amount']) ?>
          </td>
          <td><span class="badge <?= $tx['status']==='success'?'badge-active':'badge-expired' ?>"><?= $tx['status'] ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- Config Modal -->
<div class="modal-overlay" id="configModal">
  <div class="modal">
    <button class="modal-close" onclick="closeModal()">×</button>
    <h3>📋 Konfigurasi VPN</h3>
    <div id="modalContent"></div>
    <button class="btn btn-primary" style="width:100%;margin-top:1rem;" onclick="closeModal()">Tutup</button>
  </div>
</div>

<script>
function showConfig(acc) {
  let html = '';
  const fields = [
    ['Server', acc.nama_server + ' (' + acc.lokasi + ')'],
    ['Tipe VPN', acc.tipe.toUpperCase()],
    ['Username', acc.username],
    ['UUID / Password', acc.uuid || acc.password_vpn || '-'],
    ['Masa Aktif', acc.masa_aktif],
  ];
  fields.forEach(([label, val]) => {
    html += `<div class="config-row"><div class="config-label">${label}</div><div class="config-val" style="padding-right:4rem;">${val || '-'}
      <button class="copy-btn" onclick="copyText('${(val||'').replace(/'/g,"\\'")}')">Copy</button>
    </div></div>`;
  });
  if (acc.link_config) {
    html += `<div class="config-row"><div class="config-label">Link Config</div><div class="config-val" style="word-break:break-all;padding-right:4rem;">${acc.link_config}
      <button class="copy-btn" onclick="copyText('${acc.link_config.replace(/'/g,"\\'")}')">Copy</button>
    </div></div>`;
  }
  document.getElementById('modalContent').innerHTML = html;
  document.getElementById('configModal').classList.add('show');
}
function closeModal() { document.getElementById('configModal').classList.remove('show'); }
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target; btn.textContent = '✓'; setTimeout(() => btn.textContent = 'Copy', 1500);
  });
}
function deleteAccount(id, username) {
  if (!confirm(`Hapus akun "${username}"? Tindakan ini tidak bisa dibatalkan!`)) return;
  fetch('/api/delete_account.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})})
    .then(r=>r.json()).then(d => { if(d.success) location.reload(); else alert('Gagal: '+d.message); });
}
document.getElementById('configModal').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});
</script>
</body>
</html>
