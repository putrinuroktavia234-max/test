<?php
require_once __DIR__ . '/includes/config.php';
$session = requireLogin();
$db = getDB();
$userId = $session['user_id'];

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Get servers
$servers = $db->query("SELECT * FROM servers ORDER BY status DESC, harga_hari ASC")->fetchAll();

// Handle order form submission
$message = '';
$msgType = '';
$selectedServer = null;

if (isset($_GET['server'])) {
    $stmt = $db->prepare("SELECT * FROM servers WHERE code_server = ? AND status = 'ready'");
    $stmt->execute([sanitize($_GET['server'])]);
    $selectedServer = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pilih Server - <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --blue: #2563eb; --blue-dark: #1d4ed8;
  --bg: #0f172a; --card: #1e293b; --card2: #162032;
  --border: #334155; --text: #f1f5f9; --muted: #94a3b8;
  --radius: 12px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
.navbar { background: var(--card); border-bottom: 1px solid var(--border); padding: 0 1.5rem; height: 60px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; }
.nav-brand { font-weight: 700; font-size: 1.1rem; }
.nav-links { display: flex; align-items: center; gap: 1rem; }
.nav-links a { color: var(--muted); text-decoration: none; font-size: 0.875rem; font-weight: 500; padding: 0.4rem 0.75rem; border-radius: 8px; transition: all 0.2s; }
.nav-links a:hover, .nav-links a.active { color: var(--text); background: #334155; }
.saldo-badge { background: #14532d33; border: 1px solid #16a34a44; padding: 0.4rem 0.9rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; color: #4ade80; }
.bottom-nav { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--card); border-top: 1px solid var(--border); z-index: 100; }
.bottom-nav a { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 0.75rem 0.5rem; color: var(--muted); text-decoration: none; font-size: 0.7rem; gap: 0.25rem; }
.bottom-nav a.active { color: var(--blue); }
.bottom-nav a span { font-size: 1.1rem; }
.container { max-width: 1100px; margin: 0 auto; padding: 1.5rem; }
.page-title { font-size: 1.4rem; font-weight: 700; margin-bottom: 0.5rem; }
.page-sub { color: var(--muted); font-size: 0.9rem; margin-bottom: 2rem; }
.servers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.25rem; }
.server-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; transition: border-color 0.2s, transform 0.2s; }
.server-card:hover { border-color: var(--blue); transform: translateY(-2px); }
.server-card.selected { border-color: var(--blue); border-width: 2px; }
.server-head { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); background: #162032; }
.server-name { font-weight: 700; font-size: 0.95rem; color: #60a5fa; letter-spacing: 0.03em; }
.server-code { font-size: 0.75rem; color: var(--muted); margin-top: 2px; }
.server-body { padding: 0; }
.server-row { display: flex; justify-content: space-between; padding: 0.65rem 1.25rem; border-bottom: 1px solid #1e293b; font-size: 0.85rem; }
.server-row:last-child { border-bottom: none; }
.row-key { color: var(--muted); }
.row-val { font-weight: 500; }
.server-foot { padding: 1rem 1.25rem; border-top: 1px solid var(--border); display: flex; gap: 0.75rem; align-items: center; justify-content: space-between; }
.status-badge { display: inline-flex; align-items: center; gap: 4px; padding: 0.35rem 0.8rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
.status-ready { background: #14532d44; color: #4ade80; border: 1px solid #16a34a44; }
.status-maintenance { background: #78350f44; color: #fcd34d; border: 1px solid #92400e44; }
.status-offline { background: #7f1d1d44; color: #f87171; border: 1px solid #7f1d1d44; }
.btn-order { background: var(--blue); color: white; padding: 0.5rem 1.25rem; border-radius: 8px; font-size: 0.875rem; font-weight: 600; cursor: pointer; border: none; font-family: inherit; text-decoration: none; display: inline-flex; align-items: center; gap: 0.4rem; transition: background 0.2s; }
.btn-order:hover { background: var(--blue-dark); }
.btn-order:disabled { background: #334155; color: var(--muted); cursor: not-allowed; }

/* Order Form */
.order-section { margin-top: 2.5rem; }
.order-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; max-width: 700px; }
.order-head { padding: 1.25rem 1.5rem; background: #162032; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 0.75rem; }
.order-head h2 { font-size: 1rem; font-weight: 700; }
.order-body { padding: 1.5rem; }
.server-detail-table { width: 100%; border-collapse: collapse; margin-bottom: 1.5rem; }
.server-detail-table td { padding: 0.6rem 1rem; border: 1px solid var(--border); font-size: 0.875rem; }
.server-detail-table td:first-child { background: #162032; font-weight: 500; color: var(--muted); width: 40%; }
.form-group { margin-bottom: 1.25rem; }
label { display: block; font-size: 0.85rem; font-weight: 600; color: var(--muted); margin-bottom: 0.5rem; }
.tipe-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
.tipe-btn { background: #162032; border: 1.5px solid var(--border); border-radius: 10px; padding: 0.85rem; text-align: center; cursor: pointer; transition: all 0.2s; }
.tipe-btn:hover { border-color: var(--blue); }
.tipe-btn.active { border-color: var(--blue); background: #1e3a8a33; }
.tipe-btn .tipe-icon { font-size: 1.4rem; margin-bottom: 0.25rem; display: block; }
.tipe-btn .tipe-name { font-size: 0.85rem; font-weight: 600; display: block; }
input[type="text"], input[type="number"] {
  width: 100%; padding: 0.75rem 1rem; background: #0f172a; border: 1px solid var(--border);
  border-radius: 8px; color: var(--text); font-size: 0.95rem; font-family: inherit; outline: none;
}
input:focus { border-color: var(--blue); }
input::placeholder { color: #475569; }
.price-info { background: #0f172a; border: 1px solid var(--border); border-radius: 10px; padding: 1rem; margin-bottom: 1.25rem; }
.price-row { display: flex; justify-content: space-between; font-size: 0.875rem; margin-bottom: 0.4rem; }
.price-row.total { font-weight: 700; font-size: 1rem; padding-top: 0.5rem; border-top: 1px solid var(--border); margin-top: 0.4rem; }
.price-row.saldo { color: #4ade80; }
.saldo-warn { color: #f87171; font-size: 0.8rem; margin-top: 0.5rem; }
.btn-submit { width: 100%; padding: 0.9rem; background: var(--blue); color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 700; cursor: pointer; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 0.5rem; transition: background 0.2s; }
.btn-submit:hover { background: var(--blue-dark); }
.alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.25rem; font-size: 0.875rem; }
.alert-error { background: #7f1d1d22; border: 1px solid #7f1d1d; color: #fca5a5; }
.alert-success { background: #14532d22; border: 1px solid #14532d; color: #86efac; }
@media (max-width: 768px) {
  .navbar .nav-links { display: none; }
  .bottom-nav { display: flex; }
  .container { padding: 1rem; padding-bottom: 5rem; }
  .servers-grid { grid-template-columns: 1fr; }
  .tipe-grid { grid-template-columns: repeat(3, 1fr); }
}
</style>
</head>
<body>
<nav class="navbar">
  <div class="nav-brand">🛡️ <?= APP_NAME ?></div>
  <div class="nav-links">
    <a href="/dashboard.php">📊 Dashboard</a>
    <a href="/servers.php" class="active">🖥️ Server</a>
    <a href="/topup.php">💰 Topup</a>
  </div>
  <div style="display:flex;align-items:center;gap:1rem;">
    <span class="saldo-badge">💰 <?= formatRupiah($user['saldo']) ?></span>
    <a href="/logout.php" style="color:var(--muted);text-decoration:none;font-size:0.875rem;">Logout</a>
  </div>
</nav>
<nav class="bottom-nav">
  <a href="/dashboard.php"><span>📊</span>Dashboard</a>
  <a href="/servers.php" class="active"><span>🖥️</span>Server</a>
  <a href="/topup.php"><span>💰</span>Topup</a>
  <a href="/logout.php"><span>🚪</span>Logout</a>
</nav>

<div class="container">
  <div class="page-title">Pilih Server</div>
  <div class="page-sub">Pilih server VPN yang tersedia dan sesuai kebutuhanmu</div>
  
  <div class="servers-grid">
    <?php foreach ($servers as $srv): ?>
    <div class="server-card <?= ($selectedServer && $selectedServer['id']==$srv['id']) ? 'selected' : '' ?>">
      <div class="server-head">
        <div class="server-name"><?= htmlspecialchars($srv['nama_server']) ?></div>
        <div class="server-code">Code: <?= htmlspecialchars($srv['code_server']) ?></div>
      </div>
      <div class="server-body">
        <div class="server-row"><span class="row-key">Code Server</span><span class="row-val"><?= htmlspecialchars($srv['code_server']) ?></span></div>
        <div class="server-row"><span class="row-key">Lokasi</span><span class="row-val">📍 <?= htmlspecialchars($srv['lokasi']) ?></span></div>
        <div class="server-row"><span class="row-key">Harga per Hari</span><span class="row-val" style="color:#60a5fa;"><?= formatRupiah($srv['harga_hari']) ?></span></div>
        <div class="server-row"><span class="row-key">Harga per Bulan</span><span class="row-val" style="color:#60a5fa;"><?= formatRupiah($srv['harga_bulan']) ?></span></div>
        <div class="server-row"><span class="row-key">IP Limit</span><span class="row-val"><?= $srv['ip_limit'] ?> Device</span></div>
        <div class="server-row"><span class="row-key">Quota Limit</span><span class="row-val"><?= $srv['quota_limit'] ?> GB</span></div>
        <div class="server-row"><span class="row-key">STB</span><span class="row-val"><?= $srv['stb_allowed'] ? 'diperbolehkan' : 'tidak' ?></span></div>
      </div>
      <div class="server-foot">
        <span class="status-badge status-<?= $srv['status'] ?>">
          <?= $srv['status'] === 'ready' ? '● Ready' : ($srv['status'] === 'maintenance' ? '⚠ Maintenance' : '✕ Offline') ?>
        </span>
        <?php if ($srv['status'] === 'ready'): ?>
        <a href="/servers.php?server=<?= urlencode($srv['code_server']) ?>#order" class="btn-order">🛒 Order</a>
        <?php else: ?>
        <button class="btn-order" disabled>Tidak Tersedia</button>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Order Form -->
  <?php if ($selectedServer): ?>
  <div class="order-section" id="order">
    <div class="order-card">
      <div class="order-head">
        <span>🛒</span>
        <h2>Form Pemesanan VPN - <?= htmlspecialchars($selectedServer['nama_server']) ?></h2>
      </div>
      <div class="order-body">
        <div id="alertBox" style="display:none;"></div>
        
        <div class="price-info" style="margin-bottom:1.5rem;">
          <div class="price-row saldo">
            <span>💰 Saldo Anda</span>
            <span id="displaySaldo"><?= formatRupiah($user['saldo']) ?></span>
          </div>
        </div>
        
        <table class="server-detail-table">
          <tr><td>Nama Server</td><td><?= htmlspecialchars($selectedServer['nama_server']) ?></td></tr>
          <tr><td>Code Server</td><td><?= htmlspecialchars($selectedServer['code_server']) ?></td></tr>
          <tr><td>Quota Limit (GB)</td><td><?= $selectedServer['quota_limit'] ?> GB</td></tr>
          <tr><td>IP Limit</td><td><?= $selectedServer['ip_limit'] ?> Device</td></tr>
          <tr><td>Harga per Hari</td><td><?= formatRupiah($selectedServer['harga_hari']) ?></td></tr>
          <tr><td>Harga per Bulan</td><td><?= formatRupiah($selectedServer['harga_bulan']) ?></td></tr>
          <tr><td>Lokasi</td><td><?= htmlspecialchars($selectedServer['lokasi']) ?></td></tr>
          <tr><td>Status</td><td><span class="status-badge status-ready" style="padding:0.2rem 0.6rem;">● ready</span></td></tr>
        </table>
        
        <div class="form-group">
          <label>Tipe VPN</label>
          <div class="tipe-grid" id="tipeGrid">
            <div class="tipe-btn active" onclick="setTipe('vmess', this)">
              <span class="tipe-icon">☁️</span>
              <span class="tipe-name">VMess</span>
            </div>
            <div class="tipe-btn" onclick="setTipe('vless', this)">
              <span class="tipe-icon">⚡</span>
              <span class="tipe-name">VLess</span>
            </div>
            <div class="tipe-btn" onclick="setTipe('trojan', this)">
              <span class="tipe-icon">🛡️</span>
              <span class="tipe-name">Trojan</span>
            </div>
          </div>
          <input type="hidden" id="selectedTipe" value="vmess">
        </div>
        
        <div class="form-group">
          <label>Nama VPN (Remarks)</label>
          <input type="text" id="remarks" placeholder="Masukkan nama VPN (contoh: myVPN01)">
        </div>
        
        <div class="form-group">
          <label>Masa Aktif (Hari) — <span style="color:#60a5fa;">1 sampai 360</span></label>
          <input type="number" id="masaAktif" placeholder="Contoh: 30" min="1" max="360" value="30" oninput="updatePrice()">
        </div>
        
        <div class="price-info">
          <div class="price-row"><span>Server</span><span><?= htmlspecialchars($selectedServer['nama_server']) ?></span></div>
          <div class="price-row"><span>Harga per Hari</span><span><?= formatRupiah($selectedServer['harga_hari']) ?></span></div>
          <div class="price-row"><span>Masa Aktif</span><span id="priceDays">30 hari</span></div>
          <div class="price-row total">
            <span>Total Bayar</span>
            <span id="priceTotal" style="color:#60a5fa;"><?= formatRupiah($selectedServer['harga_hari'] * 30) ?></span>
          </div>
          <div id="saldoWarning" class="saldo-warn" style="display:none;">⚠️ Saldo tidak mencukupi! Silakan <a href="/topup.php" style="color:#fbbf24;">topup dulu</a>.</div>
        </div>
        
        <button class="btn-submit" id="btnOrder" onclick="submitOrder()">
          ☑️ Buat Order VPN
        </button>
      </div>
    </div>
  </div>
  
  <script>
  const hargaHari = <?= $selectedServer['harga_hari'] ?>;
  const saldo = <?= $user['saldo'] ?>;
  const serverId = <?= $selectedServer['id'] ?>;
  
  function setTipe(tipe, el) {
    document.querySelectorAll('.tipe-btn').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('selectedTipe').value = tipe;
  }
  
  function updatePrice() {
    const days = parseInt(document.getElementById('masaAktif').value) || 0;
    const total = hargaHari * days;
    document.getElementById('priceDays').textContent = days + ' hari';
    document.getElementById('priceTotal').textContent = 'Rp ' + total.toLocaleString('id-ID');
    document.getElementById('saldoWarning').style.display = total > saldo ? 'block' : 'none';
  }
  
  function submitOrder() {
    const remarks = document.getElementById('remarks').value.trim();
    const days = parseInt(document.getElementById('masaAktif').value);
    const tipe = document.getElementById('selectedTipe').value;
    const total = hargaHari * days;
    
    if (!remarks) { showAlert('error', 'Nama VPN wajib diisi!'); return; }
    if (!days || days < 1 || days > 360) { showAlert('error', 'Masa aktif harus antara 1-360 hari!'); return; }
    if (total > saldo) { showAlert('error', 'Saldo tidak mencukupi! Silakan topup terlebih dahulu.'); return; }
    
    if (!confirm(`Order VPN ${tipe.toUpperCase()} selama ${days} hari?\nTotal: Rp ${total.toLocaleString('id-ID')}`)) return;
    
    const btn = document.getElementById('btnOrder');
    btn.disabled = true; btn.textContent = '⏳ Memproses...';
    
    fetch('/api/create_order.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({server_id: serverId, tipe, remarks, days})
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        showAlert('success', '✅ Order berhasil! Akun VPN telah dibuat. Mengalihkan ke dashboard...');
        setTimeout(() => window.location.href = '/dashboard.php', 2000);
      } else {
        showAlert('error', '❌ ' + data.message);
        btn.disabled = false; btn.textContent = '☑️ Buat Order VPN';
      }
    }).catch(e => {
      showAlert('error', 'Terjadi kesalahan koneksi.');
      btn.disabled = false; btn.textContent = '☑️ Buat Order VPN';
    });
  }
  
  function showAlert(type, msg) {
    const box = document.getElementById('alertBox');
    box.className = 'alert alert-' + (type === 'error' ? 'error' : 'success');
    box.textContent = msg; box.style.display = 'block';
    box.scrollIntoView({behavior:'smooth'});
  }
  
  updatePrice();
  </script>
  <?php endif; ?>
</div>
</body>
</html>
