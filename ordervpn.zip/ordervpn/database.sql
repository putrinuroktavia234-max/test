-- OrderVPN Database Schema
-- Run this first: mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS ordervpn_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ordervpn_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    saldo DECIMAL(15,2) DEFAULT 0.00,
    role ENUM('user','admin') DEFAULT 'user',
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Servers table
CREATE TABLE IF NOT EXISTS servers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_server VARCHAR(100) NOT NULL,
    code_server VARCHAR(20) UNIQUE NOT NULL,
    lokasi VARCHAR(100) NOT NULL,
    harga_hari DECIMAL(10,2) NOT NULL,
    harga_bulan DECIMAL(10,2) NOT NULL,
    ip_limit INT DEFAULT 2,
    quota_limit INT DEFAULT 9999,
    stb_allowed BOOLEAN DEFAULT TRUE,
    status ENUM('ready','maintenance','offline') DEFAULT 'ready',
    host VARCHAR(255) NOT NULL,
    port INT DEFAULT 22,
    ssh_user VARCHAR(50) DEFAULT 'root',
    ssh_key VARCHAR(255),
    xray_port_vmess INT DEFAULT 443,
    xray_port_vless INT DEFAULT 8443,
    xray_port_trojan INT DEFAULT 2083,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- VPN Accounts table
CREATE TABLE IF NOT EXISTS vpn_accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    server_id INT NOT NULL,
    tipe ENUM('vmess','vless','trojan','ssh') NOT NULL,
    username VARCHAR(100) NOT NULL,
    remarks VARCHAR(100),
    uuid VARCHAR(36),
    password_vpn VARCHAR(255),
    link_config TEXT,
    masa_aktif DATE NOT NULL,
    days_ordered INT NOT NULL,
    harga_total DECIMAL(10,2) NOT NULL,
    status ENUM('active','expired','suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('topup','order','refund') NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    keterangan VARCHAR(255),
    status ENUM('pending','success','failed') DEFAULT 'success',
    ref_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Topup requests
CREATE TABLE IF NOT EXISTS topup_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'manual',
    bukti_transfer VARCHAR(255),
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_note VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert admin user (password: admin123)
INSERT INTO users (username, email, password, saldo, role) VALUES
('admin', 'admin@ordervpn.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 999999.00, 'admin');

-- Insert sample servers
INSERT INTO servers (nama_server, code_server, lokasi, harga_hari, harga_bulan, host, status) VALUES
('ANYM NETWORK', 'vip4', 'Indonesia', 300, 9000, '103.1.1.1', 'ready'),
('BIZNET', 'vip3', 'Indonesia', 300, 9000, '103.1.1.2', 'ready'),
('CLOUD HOST 1', 'vip1', 'Indonesia', 350, 10500, '103.1.1.3', 'ready'),
('CLOUD HOST 2', 'vip2', 'Indonesia', 300, 9000, '103.1.1.4', 'ready'),
('CTN NEW', 'vip5', 'Indonesia', 300, 9000, '103.1.1.5', 'ready'),
('DEWABIZ 1', 'vip6', 'Indonesia', 250, 7500, '103.1.1.6', 'ready'),
('DIGITAL OCEAN 2', 'vip10', 'Singapura', 400, 12000, '103.1.1.7', 'ready'),
('DIGITAL OCEAN 3', 'vip11', 'Singapura', 400, 12000, '103.1.1.8', 'ready'),
('HERZA 1', 'vip9', 'Bogor, Indonesia', 300, 9000, '103.1.1.9', 'ready');
