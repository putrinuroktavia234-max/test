<?php
require_once 'includes/config.php';
requireLogin();

$db = getDB();
$user_id = $_SESSION['user_id'];
$user = getCurrentUser();

// Get stats
$stmt = $db->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN masa_aktif > NOW() THEN 1 ELSE 0 END) as active FROM vpn_accounts WHERE user_id = ?");
$stmt->execute([$user_id]);
$stats = $stmt->fetch();

$stmt = $db->prepare("SELECT COUNT(*) as expired FROM vpn_accounts WHERE user_id = ? AND masa_aktif <= NOW()");
$stmt->execute([$user_id]);
$expired_count = $stmt->fetch()['expired'];

$stmt = $db->prepare("SELECT COUNT(*) as total_orders FROM vpn_accounts WHERE user_id = ?");
$stmt->execute([$user_id]);
$total_orders = $stmt->fetch()['total_orders'];

// Get active VPN accounts
$stmt = $db->prepare("SELECT va.*, s.nama_server as server_name, s.lokasi as server_location FROM vpn_accounts va LEFT JOIN servers s ON va.server_id = s.id WHERE va.user_id = ? ORDER BY va.created_at DESC");
$stmt->execute([$user_id]);
$accounts = $stmt->fetchAll();

// Get transactions
$stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4 animate-fade-in">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#orderModal">
        <i class="fas fa-cart-plus me-1"></i> Order Baru
    </button>
</div>

<!-- Stats Cards -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4 animate-fade-in animate-delay-1">
        <div class="card stat-card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-primary">Saldo</div>
                        <div class="stat-value text-gray-800"><?= formatRupiah($user['saldo'] ?? 0) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-wallet fa-3x text-gray-300"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <a href="topup.php" class="text-decoration-none small">Top Up <i class="fas fa-arrow-right ms-1"></i></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4 animate-fade-in animate-delay-2">
        <div class="card stat-card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-success">Aktif</div>
                        <div class="stat-value text-gray-800"><?= $stats['active'] ?? 0 ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-3x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4 animate-fade-in animate-delay-3">
        <div class="card stat-card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-warning">Expired</div>
                        <div class="stat-value text-gray-800"><?= $expired_count ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clock fa-3x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4 animate-fade-in animate-delay-4">
        <div class="card stat-card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="stat-label text-info">Total Order</div>
                        <div class="stat-value text-gray-800"><?= $total_orders ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-shopping-cart fa-3x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- VPN Accounts -->
<div class="card shadow mb-4 animate-fade-in">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-server me-2"></i>Akun VPN Saya
        </h6>
        <span class="badge bg-primary badge-custom"><?= count($accounts) ?> akun</span>
    </div>
    <div class="card-body">
        <?php if (empty($accounts)): ?>
        <div class="text-center py-5">
            <i class="fas fa-server fa-4x text-gray-300 mb-3"></i>
            <p class="text-muted">Belum ada akun VPN. Pesan sekarang!</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#orderModal">
                <i class="fas fa-cart-plus me-1"></i> Order VPN
            </button>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th>Akun</th>
                        <th>Tipe</th>
                        <th>Server</th>
                        <th>Expired</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($accounts as $acc): 
                        $is_expired = strtotime($acc['masa_aktif']) <= time();
                    ?>
                    <tr id="account-<?= $acc['id'] ?>">
                        <td><strong><?= sanitize($acc['username']) ?></strong></td>
                        <td><span class="badge bg-info badge-custom"><?= strtoupper($acc['type']) ?></span></td>
                        <td><?= sanitize($acc['server_name']) ?></td>
                        <td><?= date('d M Y', strtotime($acc['masa_aktif'])) ?></td>
                        <td>
                            <span class="badge badge-custom <?= $is_expired ? 'badge-expired' : 'badge-active' ?>">
                                <?= $is_expired ? 'Expired' : 'Aktif' ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="copyConfig('config-<?= $acc['id'] ?>')">
                                <i class="fas fa-copy"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteAccount(<?= $acc['id'] ?>, '<?= $acc['type'] ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                            
                            <!-- Hidden config data -->
                            <div id="config-<?= $acc['id'] ?>" style="display:none;">
                                Tipe: <?= strtoupper($acc['type']) ?>
                                Username: <?= sanitize($acc['username']) ?>
                                <?php if ($acc['link_config']): ?>Config: <?= $acc['link_config'] ?><?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Recent Transactions -->
<div class="card shadow mb-4 animate-fade-in">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-history me-2"></i>Riwayat Transaksi
        </h6>
    </div>
    <div class="card-body">
        <?php if (empty($transactions)): ?>
        <p class="text-muted text-center py-3">Belum ada transaksi</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th>Tipe</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td><span class="badge badge-custom <?= $tx['type'] == 'topup' ? 'badge-active' : 'badge-pending' ?>"><?= ucfirst($tx['type']) ?></span></td>
                        <td><?= formatRupiah($tx['amount']) ?></td>
                        <td><span class="badge badge-custom <?= $tx['status'] == 'completed' ? 'badge-active' : 'badge-pending' ?>"><?= ucfirst($tx['status']) ?></span></td>
                        <td><?= timeAgo($tx['created_at']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

<?php require_once 'includes/footer.php'; ?>
