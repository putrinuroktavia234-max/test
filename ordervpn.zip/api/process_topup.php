<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
$status = $_POST['status'] ?? '';

if (!in_array($status, ['approved', 'rejected'])) {
    echo json_encode(['success' => false, 'message' => 'Status tidak valid']);
    exit;
}

try {
    $db = getDB();
    
    // Get topup request
    $stmt = $db->prepare("SELECT * FROM topup_requests WHERE id = ? AND status = 'pending'");
    $stmt->execute([$id]);
    $request = $stmt->fetch();
    
    if (!$request) {
        echo json_encode(['success' => false, 'message' => 'Permintaan tidak ditemukan atau sudah diproses']);
        exit;
    }
    
    if ($status === 'approved') {
        // Add balance to user
        $stmt = $db->prepare("UPDATE users SET saldo = saldo + ? WHERE id = ?");
        $stmt->execute([$request['amount'], $request['user_id']]);
        
        // Record transaction
        $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, status, description, created_at) VALUES (?, 'topup', ?, 'completed', 'Top up saldo', NOW())");
        $stmt->execute([$request['user_id'], $request['amount']]);
    }
    
    // Update request status
    $stmt = $db->prepare("UPDATE topup_requests SET status = ?, processed_at = NOW(), processed_by = ? WHERE id = ?");
    $stmt->execute([$status, $_SESSION['user_id'], $id]);
    
    echo json_encode(['success' => true, 'message' => 'Topup ' . ($status === 'approved' ? 'disetujui' : 'ditolak')]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
