<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$user_id = intval($_POST['user_id'] ?? 0);
$amount = intval($_POST['amount'] ?? 0);

if ($user_id < 1 || $amount == 0) {
    echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
    exit;
}

try {
    $db = getDB();
    $stmt = $db->prepare("UPDATE users SET saldo = saldo + ? WHERE id = ?");
    $stmt->execute([$amount, $user_id]);
    
    $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, status, description, created_at) VALUES (?, 'adjustment', ?, 'completed', 'Manual adjustment by admin', NOW())");
    $stmt->execute([$user_id, $amount]);
    
    echo json_encode(['success' => true, 'message' => 'Saldo adjusted']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
