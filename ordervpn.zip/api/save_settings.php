<?php
/**
 * OrderVPN - Save Settings API
 * Admin endpoint to update app_settings
 */
require_once __DIR__ . '/../includes/config.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Method not allowed']));
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    exit(json_encode(['success' => false, 'message' => 'Invalid token']));
}

try {
    $db = getDB();
    
    // List of allowed settings keys
    $allowed_keys = [
        'app_name', 'app_tagline', 'login_page_title', 'login_page_subtitle',
        'footer_text', 'theme_primary_color', 'theme_secondary_color',
        'store_address', 'store_phone', 'store_email',
        'whatsapp', 'telegram_channel', 'telegram_group',
        'instagram', 'facebook', 'twitter', 'youtube',
        'bank_name', 'bank_account', 'bank_holder',
        'promo_popup_title', 'promo_popup_message', 'promo_popup_image',
        'promo_popup_enabled', 'promo_banner_text', 'promo_banner_enabled',
        'register_enabled', 'maintenance_mode', 'contact_form_enabled'
    ];
    
    $updated = 0;
    foreach ($allowed_keys as $key) {
        if (isset($_POST[$key])) {
            $val = $_POST[$key];
            $stmt = $db->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            $stmt->execute([$key, $val]);
            $updated++;
        }
    }
    
    // Clear settings cache
    
    echo json_encode(['success' => true, 'message' => "$updated pengaturan berhasil disimpan"]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
