<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

try {
    $db = getDB();
    $stmt = $db->query("SELECT id, nama_server, lokasi, harga_bulan, ip_limit, host, port, status FROM servers WHERE status = 'ready' ORDER BY nama_server ASC");
    $servers = $stmt->fetchAll();
    echo json_encode(['success' => true, 'data' => $servers]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
