<?php
/**
 * OrderVPN - API: Delete Account
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/vpn_manager.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$account_id = intval($_POST['id'] ?? 0);
if ($account_id < 1) {
    echo json_encode(['success' => false, 'message' => 'ID tidak valid']);
    exit;
}

$manager = new VPNManager();
echo json_encode($manager->deleteAccount($account_id));
