<?php
/**
 * OrderVPN - API: Create Order
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/vpn_manager.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$type = $_POST['type'] ?? '';
$server_id = $_POST['server_id'] ?? '';
$username = sanitize($_POST['username'] ?? '');
$days = intval($_POST['days'] ?? 30);

if (empty($type) || empty($server_id) || empty($username) || $days < 1) {
    echo json_encode(['success' => false, 'message' => 'Semua field harus diisi']);
    exit;
}

if (strlen($username) < 3 || strlen($username) > 20) {
    echo json_encode(['success' => false, 'message' => 'Username 3-20 karakter']);
    exit;
}

$manager = new VPNManager();
$result = $manager->createAccount($_SESSION['user_id'], $type, $server_id, $username, $days);
echo json_encode($result);
