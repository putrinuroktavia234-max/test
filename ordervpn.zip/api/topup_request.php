<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrf)) {
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$amount = intval($_POST['amount'] ?? 0);
if ($amount < 5000 || $amount > 1000000) {
    echo json_encode(['success' => false, 'message' => 'Jumlah tidak valid (min Rp5.000, max Rp1.000.000)']);
    exit;
}

// Handle file upload
if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Upload bukti transfer']);
    exit;
}

$allowed = ['image/jpeg', 'image/png', 'image/jpg'];
if (!in_array($_FILES['proof']['type'], $allowed)) {
    echo json_encode(['success' => false, 'message' => 'Format harus JPG/PNG']);
    exit;
}

if ($_FILES['proof']['size'] > 2097152) {
    echo json_encode(['success' => false, 'message' => 'Maksimal 2MB']);
    exit;
}

$ext = pathinfo($_FILES['proof']['name'], PATHINFO_EXTENSION);
$filename = 'topup_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
$upload_path = __DIR__ . '/../uploads/bukti/' . $filename;

if (!move_uploaded_file($_FILES['proof']['tmp_name'], $upload_path)) {
    echo json_encode(['success' => false, 'message' => 'Gagal upload file']);
    exit;
}

try {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO topup_requests (user_id, amount, bukti_transfer, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
    $stmt->execute([$_SESSION['user_id'], $amount, $filename]);
    
    echo json_encode(['success' => true, 'message' => 'Permintaan topup berhasil dikirim. Tunggu konfirmasi admin.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
