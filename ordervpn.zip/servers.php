<?php
require_once 'includes/config.php';
requireLogin();

$db = getDB();
$stmt = $db->query("SELECT * FROM servers ORDER BY nama_server ASC");
$servers = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4 animate-fade-in">
    <h1 class="h3 mb-0 text-gray-800">Server VPN</h1>
</div>

<div class="row">
    <?php if (empty($servers)): ?>
    <div class="col-12 text-center py-5">
        <i class="fas fa-server fa-4x text-gray-300 mb-3"></i>
        <p class="text-muted">Belum ada server tersedia</p>
    </div>
    <?php else: ?>
        <?php foreach ($servers as $server): 
            $is_online = $server['status'] == 'active';
        ?>
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card server-card h-100 shadow-sm animate-fade-in">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title mb-1"><?= sanitize($server['nama_server']) ?></h5>
                            <small class="text-muted">
                                <i class="fas fa-map-marker-alt me-1"></i><?= sanitize($server['lokasi']) ?>
                            </small>
                        </div>
                        <span class="server-status <?= $is_online ? 'online' : 'offline' ?>"></span>
                    </div>
                    
                    <div class="mb-3">
                        <div class="row text-center">
                            <div class="col-6 border-end">
                                <small class="text-muted d-block">Harga/Bulan</small>
                                <strong><?= formatRupiah($server['harga_bulan']) ?></strong>
                            </div>
                            <div class="col-6">
                                <small class="text-muted d-block">Limit IP</small>
                                <strong><?= $server['ip_limit'] ?></strong>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-2">
                        <small class="text-muted d-block">Host: <?= sanitize($server['host']) ?></small>
                        <small class="text-muted d-block">Port: <?= $server['port'] ?></small>
                    </div>
                    
                    <button class="btn btn-primary btn-sm w-100 mt-2" data-bs-toggle="modal" data-bs-target="#orderModal">
                        <i class="fas fa-cart-plus me-1"></i> Order di Server Ini
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
